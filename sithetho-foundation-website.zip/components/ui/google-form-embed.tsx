"use client";

import { cn } from "@/lib/utils";

interface GoogleFormEmbedProps {
  src: string;
  title: string;
  className?: string;
  height?: string;
}

export function GoogleFormEmbed({
  src,
  title,
  className,
  height = "800px",
}: GoogleFormEmbedProps) {
  // Check if the URL is a placeholder
  const isPlaceholder = src.includes("YOUR_FORM_ID");

  if (isPlaceholder) {
    return (
      <div
        className={cn(
          "rounded-2xl bg-card border border-border/50 p-8 text-center",
          className
        )}
        style={{ minHeight: height }}
      >
        <div className="flex flex-col items-center justify-center h-full min-h-[400px]">
          <div className="rounded-full bg-muted p-4 mb-4">
            <svg
              className="h-8 w-8 text-muted-foreground"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-foreground mb-2">
            {title}
          </h3>
          <p className="text-muted-foreground max-w-md">
            The form will be displayed here once the Google Form URL is configured.
            Please contact the administrator to set up this form.
          </p>
          <p className="mt-4 text-sm text-muted-foreground">
            In the meantime, you can{" "}
            <a
              href="https://wa.me/27791296823"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary hover:underline"
            >
              contact us via WhatsApp
            </a>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "rounded-2xl bg-card border border-border/50 overflow-hidden",
        className
      )}
    >
      <iframe
        src={src}
        title={title}
        width="100%"
        height={height}
        frameBorder="0"
        marginHeight={0}
        marginWidth={0}
        className="w-full"
      >
        Loading...
      </iframe>
    </div>
  );
}
