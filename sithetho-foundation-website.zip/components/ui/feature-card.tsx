import Link from "next/link";
import { cn } from "@/lib/utils";
import { GraduationCap, School, Calculator, Compass, Wallet, Calendar, Recycle, Award, Truck, BarChart3, type LucideIcon } from "lucide-react";

const iconMap: Record<string, LucideIcon> = {
  GraduationCap,
  School,
  Calculator,
  Compass,
  Wallet,
  Calendar,
  Recycle,
  Award,
  Truck,
  BarChart3,
};

interface FeatureCardProps {
  title: string;
  description: string;
  href: string;
  icon?: string;
  variant?: "default" | "large";
  className?: string;
}

export function FeatureCard({
  title,
  description,
  href,
  icon,
  variant = "default",
  className,
}: FeatureCardProps) {
  const Icon = icon ? iconMap[icon] : GraduationCap;

  if (variant === "large") {
    return (
      <Link
        href={href}
        className={cn(
          "group relative overflow-hidden rounded-3xl bg-card p-8 shadow-soft card-hover border border-border/50",
          "lg:p-10",
          className
        )}
      >
        <div className="relative z-10">
          <div className="mb-6 inline-flex items-center justify-center rounded-2xl gradient-primary p-4 text-primary-foreground">
            <Icon className="h-8 w-8" />
          </div>
          <h3 className="text-2xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors">
            {title}
          </h3>
          <p className="text-muted-foreground leading-relaxed">{description}</p>
          <div className="mt-6 inline-flex items-center text-primary font-medium">
            Learn more
            <svg
              className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </div>
        </div>
        {/* Decorative gradient */}
        <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gradient-to-br from-primary/10 to-secondary/10 blur-3xl transition-all group-hover:scale-150" />
      </Link>
    );
  }

  return (
    <Link
      href={href}
      className={cn(
        "group flex flex-col rounded-2xl bg-card p-6 shadow-soft card-hover border border-border/50",
        className
      )}
    >
      <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground w-fit">
        <Icon className="h-6 w-6" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
        {title}
      </h3>
      <p className="text-sm text-muted-foreground leading-relaxed flex-grow">{description}</p>
      <div className="mt-4 inline-flex items-center text-sm text-primary font-medium">
        Learn more
        <svg
          className="ml-1 h-3 w-3 transition-transform group-hover:translate-x-1"
          fill="none"
          viewBox="0 0 24 24"
          stroke="currentColor"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M9 5l7 7-7 7"
          />
        </svg>
      </div>
    </Link>
  );
}
