"use client";

import React from "react"

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

interface SectionProps {
  children: React.ReactNode;
  className?: string;
  id?: string;
  variant?: "default" | "muted" | "gradient";
}

export function Section({ children, className, id, variant = "default" }: SectionProps) {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
          }
        });
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  const variantStyles = {
    default: "bg-background",
    muted: "bg-muted/30",
    gradient: "gradient-primary-subtle",
  };

  return (
    <section
      ref={ref}
      id={id}
      className={cn(
        "py-16 lg:py-24",
        variantStyles[variant],
        isVisible ? "animate-fade-in-up" : "opacity-0",
        className
      )}
      style={{ animationDelay: "0.1s" }}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">{children}</div>
    </section>
  );
}
