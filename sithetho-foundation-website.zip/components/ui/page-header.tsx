import React from "react"
import Image from "next/image";
import { cn } from "@/lib/utils";

interface PageHeaderProps {
  title: string;
  description?: string;
  logo?: string;
  className?: string;
  children?: React.ReactNode;
}

export function PageHeader({
  title,
  description,
  logo,
  className,
  children,
}: PageHeaderProps) {
  return (
    <div
      className={cn(
        "relative pt-24 pb-12 lg:pt-32 lg:pb-16 gradient-primary-subtle",
        className
      )}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center text-center">
          {logo && (
            <div className="relative h-20 w-20 mb-6 lg:h-24 lg:w-24">
              <Image
                src={logo || "/placeholder.svg"}
                alt=""
                fill
                className="object-contain"
                priority
              />
            </div>
          )}
          <h1 className="text-3xl font-bold text-foreground sm:text-4xl lg:text-5xl text-balance">
            {title}
          </h1>
          {description && (
            <p className="mt-4 max-w-2xl text-lg text-muted-foreground leading-relaxed text-pretty">
              {description}
            </p>
          )}
          {children && <div className="mt-8">{children}</div>}
        </div>
      </div>
      {/* Decorative elements */}
      <div className="absolute left-0 top-0 -z-10 h-full w-full overflow-hidden">
        <div className="absolute -left-20 top-20 h-72 w-72 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -right-20 bottom-10 h-72 w-72 rounded-full bg-secondary/5 blur-3xl" />
      </div>
    </div>
  );
}
