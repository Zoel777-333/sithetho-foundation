"use client";

import { MessageCircle } from "lucide-react";
import { siteConfig } from "@/data/site";

export function WhatsAppButton() {
  return (
    <a
      href={siteConfig.contact.whatsappLink}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-2 rounded-full bg-[#25D366] px-4 py-3 text-white shadow-lg transition-all hover:scale-105 hover:shadow-xl whatsapp-pulse"
      aria-label="Chat with us on WhatsApp"
    >
      <MessageCircle className="h-6 w-6" fill="currentColor" />
      <span className="hidden sm:inline font-medium">Chat with us</span>
    </a>
  );
}
