import Link from "next/link";
import Image from "next/image";
import { Mail, Phone, MapPin } from "lucide-react";
import { siteConfig } from "@/data/site";

const footerLinks = {
  clc: [
    { name: "Universities", href: "/clc/universities" },
    { name: "TVET Colleges", href: "/clc/tvet-colleges" },
    { name: "APS Calculator", href: "/clc/aps-calculator" },
    { name: "Career Guidance", href: "/clc/career-guidance" },
    { name: "NSFAS Support", href: "/clc/nsfas" },
    { name: "Book Assistance", href: "/clc/book-assistance" },
  ],
  recycling: [
    { name: "Overview", href: "/recycling" },
    { name: "Register", href: "/recycling/register" },
    { name: "Request Pickup", href: "/recycling/pickup-request" },
    { name: "Rewards", href: "/recycling/rewards" },
    { name: "Impact Dashboard", href: "/recycling/impact" },
  ],
  foundation: [
    { name: "About Us", href: "/about" },
    { name: "Sponsors", href: "/sponsors" },
    { name: "Contact", href: "/contact" },
    { name: "FAQ", href: "/faq" },
  ],
};

export function Footer() {
  return (
    <footer className="bg-card border-t border-border/50">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-12 lg:py-16">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-5">
            {/* Brand Column */}
            <div className="lg:col-span-2">
              <Link href="/" className="flex items-center gap-3">
                <div className="relative h-12 w-12">
                  <Image
                    src="/assets/nd.png"
                    alt="Sithetho Foundation Logo"
                    fill
                    className="object-contain"
                  />
                </div>
                <div>
                  <p className="text-lg font-semibold text-foreground">
                    {siteConfig.name}
                  </p>
                  <p className="text-sm text-muted-foreground">{siteConfig.tagline}</p>
                </div>
              </Link>
              <p className="mt-4 text-sm text-muted-foreground max-w-md leading-relaxed">
                {siteConfig.mission}
              </p>
              
              {/* Contact Info */}
              <div className="mt-6 space-y-3">
                <a
                  href={siteConfig.contact.whatsappLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Phone className="h-4 w-4" />
                  {siteConfig.contact.whatsapp}
                </a>
                <a
                  href={`mailto:${siteConfig.contact.email}`}
                  className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  {siteConfig.contact.email}
                </a>
                <p className="flex items-center gap-2 text-sm text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  {siteConfig.contact.location}
                </p>
              </div>
            </div>

            {/* Community Learning Center */}
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-4">
                Learning Center
              </h3>
              <ul className="space-y-3">
                {footerLinks.clc.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Recycling */}
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-4">
                Recycling
              </h3>
              <ul className="space-y-3">
                {footerLinks.recycling.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Foundation */}
            <div>
              <h3 className="text-sm font-semibold text-foreground mb-4">
                Foundation
              </h3>
              <ul className="space-y-3">
                {footerLinks.foundation.map((link) => (
                  <li key={link.name}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-primary transition-colors"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-border/50 py-6">
          <p className="text-center text-sm text-muted-foreground">
            © {siteConfig.founded} {siteConfig.name}. All rights reserved. NPO registration pending.
          </p>
        </div>
      </div>
    </footer>
  );
}
