import React from "react"
import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { WhatsAppButton } from "@/components/layout/whatsapp-button";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: {
    default: "Sithetho Foundation | Phuhlisa • Empower",
    template: "%s | Sithetho Foundation",
  },
  description:
    "Free education guidance, application support, and career counseling for South African learners. Plus community recycling initiatives for a cleaner future.",
  keywords: [
    "education",
    "university applications",
    "NSFAS",
    "APS calculator",
    "career guidance",
    "South Africa",
    "Eastern Cape",
    "Mdantsane",
    "recycling",
    "community",
    "NPO",
    "foundation",
  ],
  authors: [{ name: "Sithetho Foundation" }],
  creator: "Sithetho Foundation",
  publisher: "Sithetho Foundation",
  metadataBase: new URL("https://newdawn.mbilasegroup.com"),
  openGraph: {
    type: "website",
    locale: "en_ZA",
    url: "https://newdawn.mbilasegroup.com",
    siteName: "Sithetho Foundation",
    title: "Sithetho Foundation | Phuhlisa • Empower",
    description:
      "Free education guidance, application support, and career counseling for South African learners.",
    images: [
      {
        url: "/assets/nd.png",
        width: 800,
        height: 800,
        alt: "Sithetho Foundation Logo",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Sithetho Foundation | Phuhlisa • Empower",
    description:
      "Free education guidance and career support for South African learners.",
    images: ["/assets/nd.png"],
  },
  icons: {
    icon: "/assets/nd.png",
    shortcut: "/assets/nd.png",
    apple: "/assets/nd.png",
  },
    generator: 'v0.app'
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#f8fafc" },
    { media: "(prefers-color-scheme: dark)", color: "#1e1b4b" },
  ],
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} font-sans antialiased`}>
        <Header />
        <main className="min-h-screen">{children}</main>
        <Footer />
        <WhatsAppButton />
        <Analytics />
      </body>
    </html>
  );
}
