import type { Metadata } from "next";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { GoogleFormEmbed } from "@/components/ui/google-form-embed";
import { googleForms, assistanceHours, siteConfig } from "@/data/site";
import { Clock, MapPin, Phone, CheckCircle } from "lucide-react";

export const metadata: Metadata = {
  title: "Book Free Assistance",
  description:
    "Schedule a free one-on-one consultation with our education advisors for university applications, NSFAS, and career guidance.",
};

const whatToBring = [
  "Grade 11 final results (if Grade 12)",
  "Grade 12 mid-year results (if available)",
  "List of universities/colleges you're interested in",
  "Any questions about courses or careers",
  "ID document",
];

export default function BookAssistancePage() {
  return (
    <>
      <PageHeader
        title="Book Free Assistance"
        description="Schedule a one-on-one session with our education advisors. All consultations are completely free."
        logo="/assets/ndclc.png"
      />

      <Section variant="default">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Form */}
          <div className="lg:col-span-2">
            <GoogleFormEmbed
              src={googleForms.bookAssistance}
              title="Book Assistance Form"
              height="700px"
            />
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Availability */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <Clock className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-foreground">Availability</h3>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Monday - Friday</span>
                  <span className="font-medium text-foreground">
                    {assistanceHours.weekdays}
                  </span>
                </div>
                <div className="flex justify-between py-2 border-b border-border/50">
                  <span className="text-muted-foreground">Saturday</span>
                  <span className="font-medium text-foreground">
                    {assistanceHours.saturday}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-muted-foreground">Sunday</span>
                  <span className="font-medium text-foreground">
                    {assistanceHours.sunday}
                  </span>
                </div>
              </div>
            </div>

            {/* Location */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <MapPin className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-foreground">Location</h3>
              </div>
              <p className="text-muted-foreground">{siteConfig.contact.location}</p>
              <p className="text-sm text-muted-foreground mt-2">
                Sessions can be held in-person or via phone/WhatsApp call.
              </p>
            </div>

            {/* Quick Contact */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <Phone className="h-5 w-5" />
                </div>
                <h3 className="font-semibold text-foreground">Quick Contact</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Can't wait? Reach us directly on WhatsApp for faster response.
              </p>
              <a
                href={siteConfig.contact.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-[#25D366] text-white text-sm font-medium hover:bg-[#20BD5A] transition-colors"
              >
                <Phone className="h-4 w-4" />
                {siteConfig.contact.whatsapp}
              </a>
            </div>

            {/* What to Bring */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">
                What to Bring
              </h3>
              <ul className="space-y-3">
                {whatToBring.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-sm text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
