"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { subjectList, calculateAPS, apsLevels, apsRequirementExamples } from "@/data/aps";
import { Plus, Trash2, Calculator, Info, ArrowRight } from "lucide-react";

interface SubjectEntry {
  id: string;
  name: string;
  mark: number;
}

export default function APSCalculatorPage() {
  const [subjects, setSubjects] = useState<SubjectEntry[]>([
    { id: "1", name: "", mark: 0 },
    { id: "2", name: "", mark: 0 },
    { id: "3", name: "", mark: 0 },
    { id: "4", name: "", mark: 0 },
    { id: "5", name: "", mark: 0 },
    { id: "6", name: "", mark: 0 },
    { id: "7", name: "", mark: 0 },
  ]);
  const [result, setResult] = useState<{
    totalAPS: number;
    subjectsUsed: { name: string; mark: number; points: number }[];
    explanation: string;
  } | null>(null);

  const addSubject = () => {
    setSubjects([
      ...subjects,
      { id: Date.now().toString(), name: "", mark: 0 },
    ]);
  };

  const removeSubject = (id: string) => {
    if (subjects.length > 6) {
      setSubjects(subjects.filter((s) => s.id !== id));
    }
  };

  const updateSubject = (id: string, field: "name" | "mark", value: string | number) => {
    setSubjects(
      subjects.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const calculate = () => {
    const validSubjects = subjects
      .filter((s) => s.name && s.mark > 0)
      .map((s) => ({
        name: s.name,
        mark: s.mark,
        isLifeOrientation: s.name.toLowerCase().includes("life orientation"),
      }));

    if (validSubjects.length < 6) {
      alert("Please enter at least 6 subjects with marks to calculate your APS.");
      return;
    }

    const apsResult = calculateAPS(validSubjects);
    setResult(apsResult);
  };

  const reset = () => {
    setSubjects([
      { id: "1", name: "", mark: 0 },
      { id: "2", name: "", mark: 0 },
      { id: "3", name: "", mark: 0 },
      { id: "4", name: "", mark: 0 },
      { id: "5", name: "", mark: 0 },
      { id: "6", name: "", mark: 0 },
      { id: "7", name: "", mark: 0 },
    ]);
    setResult(null);
  };

  return (
    <>
      <PageHeader
        title="APS Calculator"
        description="Calculate your Admission Point Score (APS) to see which universities and programmes you qualify for."
        logo="/assets/ndclc.png"
      />

      <Section variant="default">
        {/* How APS Works */}
        <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-secondary/5 p-6 mb-8 border border-border/50">
          <div className="flex items-start gap-4">
            <div className="shrink-0 w-10 h-10 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
              <Info className="h-5 w-5" />
            </div>
            <div>
              <h3 className="font-semibold text-foreground mb-2">
                How APS is Calculated
              </h3>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Your APS is the sum of points from your best 6 subjects</li>
                <li>• Life Orientation is NOT included in the calculation</li>
                <li>• Each subject earns points based on your percentage mark</li>
                <li>• Maximum possible APS is 42 (7 points × 6 subjects)</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Calculator Form */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-6 flex items-center gap-2">
                <Calculator className="h-5 w-5 text-primary" />
                Enter Your Subjects & Marks
              </h2>

              <div className="space-y-4">
                {subjects.map((subject, index) => (
                  <div key={subject.id} className="flex items-center gap-3">
                    <span className="w-6 text-sm text-muted-foreground">
                      {index + 1}.
                    </span>
                    <Select
                      value={subject.name}
                      onValueChange={(value) => updateSubject(subject.id, "name", value)}
                    >
                      <SelectTrigger className="flex-1 rounded-xl">
                        <SelectValue placeholder="Select subject" />
                      </SelectTrigger>
                      <SelectContent>
                        {subjectList.map((s) => (
                          <SelectItem key={s} value={s}>
                            {s}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="relative w-24">
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        placeholder="Mark"
                        value={subject.mark || ""}
                        onChange={(e) =>
                          updateSubject(
                            subject.id,
                            "mark",
                            Math.min(100, Math.max(0, parseInt(e.target.value) || 0))
                          )
                        }
                        className="rounded-xl pr-8"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                        %
                      </span>
                    </div>
                    {subjects.length > 6 && (
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeSubject(subject.id)}
                        className="shrink-0"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <Button variant="outline" onClick={addSubject} className="rounded-xl bg-transparent">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Subject
                </Button>
                <Button
                  onClick={calculate}
                  className="gradient-primary text-primary-foreground hover:opacity-90 rounded-xl"
                >
                  <Calculator className="h-4 w-4 mr-2" />
                  Calculate APS
                </Button>
                <Button variant="ghost" onClick={reset} className="rounded-xl">
                  Reset
                </Button>
              </div>
            </div>

            {/* Result */}
            {result && (
              <div className="mt-8 rounded-2xl bg-card p-6 shadow-soft border border-border/50 animate-fade-in-up">
                <h2 className="text-xl font-semibold text-foreground mb-6">
                  Your APS Result
                </h2>

                <div className="text-center py-8 rounded-2xl gradient-primary mb-6">
                  <p className="text-sm text-primary-foreground/80 mb-2">
                    Your Admission Point Score
                  </p>
                  <p className="text-6xl font-bold text-primary-foreground">
                    {result.totalAPS}
                  </p>
                  <p className="text-sm text-primary-foreground/80 mt-2">
                    out of 42 possible points
                  </p>
                </div>

                <div className="mb-6">
                  <h3 className="font-medium text-foreground mb-3">
                    Subjects Used in Calculation:
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {result.subjectsUsed.map((s, i) => (
                      <div
                        key={i}
                        className="flex justify-between items-center p-3 rounded-xl bg-muted"
                      >
                        <span className="text-sm text-foreground">{s.name}</span>
                        <span className="text-sm">
                          <span className="text-muted-foreground">{s.mark}%</span>
                          <span className="ml-2 font-semibold text-primary">
                            ({s.points} pts)
                          </span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <p className="text-sm text-muted-foreground">{result.explanation}</p>

                <div className="mt-6 pt-6 border-t border-border/50">
                  <Button asChild className="w-full gradient-primary text-primary-foreground hover:opacity-90 rounded-xl">
                    <Link href="/clc/universities">
                      Find Universities That Match Your APS
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Link>
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Points Table */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">
                APS Points Scale
              </h3>
              <div className="space-y-2">
                {apsLevels.map((level) => (
                  <div
                    key={level.level}
                    className="flex justify-between items-center py-2 border-b border-border/50 last:border-0"
                  >
                    <span className="text-sm text-muted-foreground">
                      {level.percentage}
                    </span>
                    <span className="font-semibold text-foreground">
                      {level.points} points
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* APS Requirements */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">
                Typical APS Requirements
              </h3>
              <div className="space-y-3">
                {apsRequirementExamples.slice(0, 5).map((req) => (
                  <div key={req.programme} className="pb-3 border-b border-border/50 last:border-0">
                    <p className="font-medium text-foreground text-sm">
                      {req.programme}
                    </p>
                    <p className="text-sm text-primary font-semibold">
                      APS: {req.minAPS}
                    </p>
                    <p className="text-xs text-muted-foreground">{req.notes}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Help Card */}
            <div className="rounded-2xl gradient-primary p-6 text-primary-foreground">
              <h3 className="font-semibold mb-2">Need Help Understanding?</h3>
              <p className="text-sm text-primary-foreground/90 mb-4">
                Our advisors can explain what your APS means and which programmes
                you qualify for.
              </p>
              <Button
                asChild
                className="w-full bg-white text-primary hover:bg-white/90 rounded-xl"
              >
                <Link href="/clc/book-assistance">Book Free Session</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
