import type { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { FeatureCard } from "@/components/ui/feature-card";
import { clcServices, assistanceHours } from "@/data/site";
import { Clock, CheckCircle, ArrowRight } from "lucide-react";

export const metadata: Metadata = {
  title: "Community Learning Center",
  description:
    "Free education guidance, university applications, APS calculation, career counseling, and NSFAS support for South African learners.",
};

const freeServices = [
  "University & college application guidance",
  "APS calculation and interpretation",
  "Career counseling and assessment",
  "NSFAS application support",
  "Document preparation assistance",
  "One-on-one consultation sessions",
];

export default function CLCPage() {
  return (
    <>
      <PageHeader
        title="Community Learning Center"
        description="All our education services are completely free. We believe every learner deserves access to quality guidance, regardless of their circumstances."
        logo="/assets/ndclc.png"
      >
        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            asChild
            size="lg"
            className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8"
          >
            <Link href="/clc/universities">
              Browse Universities
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            size="lg"
            className="rounded-full px-8 border-2 bg-transparent"
          >
            <Link href="/clc/book-assistance">Book Free Session</Link>
          </Button>
        </div>
      </PageHeader>

      {/* Free Services Banner */}
      <Section variant="default">
        <div className="rounded-3xl bg-gradient-to-br from-primary/5 to-secondary/5 p-8 lg:p-12 border border-border/50">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-sm font-medium text-primary tracking-widest uppercase mb-4">
                100% Free Services
              </p>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground text-balance">
                Everything You Need to Succeed — At No Cost
              </h2>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                The Community Learning Center provides comprehensive education
                guidance without any fees. Our mission is to remove barriers to
                education, and cost should never be one of them.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {freeServices.map((service) => (
                <div key={service} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-sm text-foreground">{service}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </Section>

      {/* Services Grid */}
      <Section variant="muted">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            Our Services
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive support for every step of your education journey.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {clcServices.map((service) => (
            <FeatureCard
              key={service.id}
              title={service.title}
              description={service.description}
              href={service.href}
              icon={service.icon}
            />
          ))}
        </div>
      </Section>

      {/* Availability */}
      <Section variant="default">
        <div className="rounded-3xl bg-card p-8 lg:p-12 shadow-soft border border-border/50">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              <div className="mb-4 inline-flex items-center justify-center rounded-2xl gradient-primary p-4 text-primary-foreground">
                <Clock className="h-8 w-8" />
              </div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">
                Assistance Hours
              </h2>
              <p className="mt-2 text-muted-foreground">
                Book a session during our available times.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 lg:gap-8">
              <div className="text-center p-6 rounded-2xl bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">Monday - Friday</p>
                <p className="text-xl font-semibold text-foreground">
                  {assistanceHours.weekdays}
                </p>
              </div>
              <div className="text-center p-6 rounded-2xl bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">Saturday</p>
                <p className="text-xl font-semibold text-foreground">
                  {assistanceHours.saturday}
                </p>
              </div>
              <div className="text-center p-6 rounded-2xl bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">Sunday</p>
                <p className="text-xl font-semibold text-foreground">
                  {assistanceHours.sunday}
                </p>
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* How It Works */}
      <Section variant="muted">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            How It Works
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Getting started is simple.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="mx-auto w-16 h-16 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-2xl font-bold mb-4">
              1
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Book a Session
            </h3>
            <p className="text-muted-foreground">
              Fill out our booking form or send us a WhatsApp message to schedule
              your free consultation.
            </p>
          </div>
          <div className="text-center">
            <div className="mx-auto w-16 h-16 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-2xl font-bold mb-4">
              2
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Meet With Us
            </h3>
            <p className="text-muted-foreground">
              Come prepared with your academic records. We'll assess your options
              and create a personalized plan.
            </p>
          </div>
          <div className="text-center">
            <div className="mx-auto w-16 h-16 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-2xl font-bold mb-4">
              3
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Apply With Confidence
            </h3>
            <p className="text-muted-foreground">
              With guidance and support, submit your applications knowing you've
              done everything right.
            </p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Button
            asChild
            size="lg"
            className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8"
          >
            <Link href="/clc/book-assistance">
              Book Your Free Session
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </div>
      </Section>
    </>
  );
}
