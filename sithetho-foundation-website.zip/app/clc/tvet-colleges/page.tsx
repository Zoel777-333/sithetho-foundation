"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { colleges } from "@/data/colleges";
import { provinces } from "@/data/universities";
import { Search, MapPin, School, CheckCircle } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

const Loading = () => null;

export default function TVETCollegesPage() {
  const searchParams = useSearchParams();
  const [search, setSearch] = useState(searchParams?.get("search") || "");
  const [provinceFilter, setProvinceFilter] = useState<string>(searchParams?.get("province") || "all");
  const [typeFilter, setTypeFilter] = useState<string>(searchParams?.get("type") || "all");

  const filteredColleges = useMemo(() => {
    return colleges.filter((college) => {
      const matchSearch =
        !search ||
        college.name.toLowerCase().includes(search.toLowerCase()) ||
        college.shortName.toLowerCase().includes(search.toLowerCase()) ||
        college.city.toLowerCase().includes(search.toLowerCase());
      const matchProvince =
        provinceFilter === "all" || college.province === provinceFilter;
      const matchType = typeFilter === "all" || college.type === typeFilter;
      return matchSearch && matchProvince && matchType;
    });
  }, [search, provinceFilter, typeFilter]);

  const publicCount = colleges.filter((c) => c.type === "public-tvet").length;
  const privateCount = colleges.filter((c) => c.type === "private").length;

  return (
    <Suspense fallback={<Loading />}>
      <>
        <PageHeader
          title="TVET & Private Colleges"
          description="Explore Technical and Vocational Education and Training (TVET) colleges and private institutions for career-focused education."
          logo="/assets/ndclc.png"
        />

        <Section variant="default">
          {/* Info Banner */}
          <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-secondary/5 p-6 mb-8 border border-border/50">
            <h3 className="font-semibold text-foreground mb-2">
              What is TVET Education?
            </h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Technical and Vocational Education and Training (TVET) colleges offer
              practical, career-focused programmes that prepare you for the
              workplace. You can enter with Grade 9 (N1-N3) or Grade 12 (N4-N6)
              qualifications. TVET qualifications are highly valued by employers
              and can lead to well-paying careers in engineering, business, IT, and
              more.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{colleges.length}</p>
              <p className="text-sm text-muted-foreground">Total Colleges</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{publicCount}</p>
              <p className="text-sm text-muted-foreground">Public TVET</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{privateCount}</p>
              <p className="text-sm text-muted-foreground">Private Colleges</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{publicCount}</p>
              <p className="text-sm text-muted-foreground">NSFAS Accredited</p>
            </div>
          </div>

          {/* Filters */}
          <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search colleges..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10 rounded-xl"
                />
              </div>
              <Select value={provinceFilter} onValueChange={setProvinceFilter}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="Province" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Provinces</SelectItem>
                  {provinces.map((province) => (
                    <SelectItem key={province} value={province}>
                      {province}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="public-tvet">Public TVET</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Results */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredColleges.map((college) => (
              <Link
                key={college.id}
                href={`/clc/institution/${college.slug}`}
                className="group rounded-2xl bg-card p-6 shadow-soft border border-border/50 card-hover"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                          college.type === "public-tvet"
                            ? "bg-primary/10 text-primary"
                            : "bg-secondary/10 text-secondary"
                        }`}
                      >
                        {college.type === "public-tvet" ? "Public TVET" : "Private"}
                      </span>
                      {college.nsfasAccredited && (
                        <span className="flex items-center gap-1 text-xs text-green-600">
                          <CheckCircle className="h-3 w-3" />
                          NSFAS
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {college.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{college.shortName}</p>
                  </div>
                  <div className="shrink-0">
                    <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                      <School className="h-6 w-6" />
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {college.city}, {college.province}
                  </span>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {college.popularCourses.slice(0, 3).map((course) => (
                    <span
                      key={course}
                      className="px-2 py-1 text-xs bg-muted rounded-lg text-muted-foreground"
                    >
                      {course}
                    </span>
                  ))}
                  {college.popularCourses.length > 3 && (
                    <span className="px-2 py-1 text-xs bg-muted rounded-lg text-muted-foreground">
                      +{college.popularCourses.length - 3} more
                    </span>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Application Fee</p>
                    <p className="font-semibold text-foreground">{college.applicationFee}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Deadline</p>
                    <p className="font-semibold text-foreground">{college.applicationDeadline}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {filteredColleges.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No colleges found matching your criteria.
              </p>
              <Button
                variant="outline"
                className="mt-4 bg-transparent"
                onClick={() => {
                  setSearch("");
                  setProvinceFilter("all");
                  setTypeFilter("all");
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </Section>

        {/* Help Banner */}
        <Section variant="muted">
          <div className="rounded-3xl bg-card p-8 lg:p-12 shadow-soft border border-border/50 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Not Sure Which Path to Choose?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
              TVET colleges offer excellent career opportunities. Let our advisors
              help you understand which programmes match your skills and career
              goals.
            </p>
            <Button
              asChild
              className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8"
            >
              <Link href="/clc/book-assistance">Book Free Consultation</Link>
            </Button>
          </div>
        </Section>
      </>
    </Suspense>
  );
}
