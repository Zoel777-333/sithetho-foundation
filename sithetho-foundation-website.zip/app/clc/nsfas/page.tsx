import type { Metadata } from "next";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import {
  CheckCircle,
  AlertCircle,
  FileText,
  Calendar,
  ExternalLink,
  HelpCircle,
  ArrowRight,
  Wallet,
  Users,
  Building,
} from "lucide-react";

export const metadata: Metadata = {
  title: "NSFAS Support",
  description:
    "Step-by-step guidance for NSFAS applications, document requirements, and appeals. Get free help with your financial aid application.",
};

const eligibilityCriteria = [
  "South African citizen with a valid SA ID",
  "Combined household income of R350,000 or less per year",
  "Admitted to study at a public university or TVET college",
  "Not funded by another bursary for the same qualification",
  "Studying towards first undergraduate qualification (with exceptions)",
];

const requiredDocuments = [
  {
    title: "South African ID",
    description: "Certified copy of your ID document (not older than 3 months)",
  },
  {
    title: "Proof of Income",
    description: "Parents'/guardians' latest payslips, or if unemployed, an affidavit",
  },
  {
    title: "SASSA Proof",
    description: "If receiving SASSA grants, provide proof of SASSA grant(s)",
  },
  {
    title: "Proof of Registration",
    description: "Proof of registration or acceptance letter from your institution",
  },
  {
    title: "Consent Forms",
    description: "Signed consent forms from parents/guardians (available on NSFAS website)",
  },
  {
    title: "Proof of Disability",
    description: "If applicable, medical proof of disability for additional funding",
  },
];

const applicationSteps = [
  {
    step: 1,
    title: "Create myNSFAS Account",
    description:
      "Visit www.nsfas.org.za and create an account using your ID number, email, and cellphone number.",
  },
  {
    step: 2,
    title: "Complete Application Form",
    description:
      "Log in and fill out all required sections including personal details, household income, and institution choice.",
  },
  {
    step: 3,
    title: "Upload Documents",
    description:
      "Upload all required documents in the correct format (usually PDF, max 1MB each).",
  },
  {
    step: 4,
    title: "Submit Application",
    description:
      "Review all information carefully, then submit your application before the deadline.",
  },
  {
    step: 5,
    title: "Track Status",
    description:
      "Regularly check your application status on myNSFAS portal and respond to any queries promptly.",
  },
  {
    step: 6,
    title: "Sign Agreement",
    description:
      "If approved, sign your funding agreement (bursary contract) to activate your funding.",
  },
];

const importantDates = [
  { event: "Applications Open", date: "September (typically)" },
  { event: "Application Deadline", date: "January 31 (check annually)" },
  { event: "Results Released", date: "March-April" },
  { event: "Appeals Period", date: "Check NSFAS announcements" },
];

const coverageDetails = [
  { item: "Tuition Fees", description: "Full tuition at public institutions" },
  { item: "Accommodation", description: "University residence or private accommodation allowance" },
  { item: "Living Allowance", description: "Monthly allowance for food and personal care" },
  { item: "Book Allowance", description: "Allowance for textbooks and learning materials" },
  { item: "Transport Allowance", description: "For students not in residence (if applicable)" },
];

export default function NSFASPage() {
  return (
    <>
      <PageHeader
        title="NSFAS Support"
        description="Everything you need to know about the National Student Financial Aid Scheme. We're here to help you every step of the way."
        logo="/assets/ndclc.png"
      >
        <Button
          asChild
          size="lg"
          className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8"
        >
          <Link href="/clc/book-assistance">
            Get Free Help
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </Button>
      </PageHeader>

      <Section variant="default">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* What is NSFAS */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <Wallet className="h-6 w-6" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">
                  What is NSFAS?
                </h2>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                The National Student Financial Aid Scheme (NSFAS) is a South
                African government bursary that provides financial assistance to
                eligible students who want to study at public universities and
                TVET colleges but cannot afford the costs. NSFAS covers tuition
                fees, accommodation, and provides allowances for living expenses,
                books, and transport.
              </p>
            </div>

            {/* Eligibility */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <Users className="h-6 w-6" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">
                  Who Qualifies?
                </h2>
              </div>
              <ul className="space-y-3">
                {eligibilityCriteria.map((criteria) => (
                  <li key={criteria} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-foreground">{criteria}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* What NSFAS Covers */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <Building className="h-6 w-6" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">
                  What Does NSFAS Cover?
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {coverageDetails.map((item) => (
                  <div key={item.item} className="p-4 rounded-xl bg-muted">
                    <p className="font-medium text-foreground">{item.item}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Application Steps */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                How to Apply - Step by Step
              </h2>
              <div className="space-y-4">
                {applicationSteps.map((item) => (
                  <div key={item.step} className="flex gap-4">
                    <div className="shrink-0 w-10 h-10 rounded-full gradient-primary flex items-center justify-center text-primary-foreground font-bold">
                      {item.step}
                    </div>
                    <div className="flex-1 pb-4 border-b border-border/50 last:border-0 last:pb-0">
                      <h3 className="font-medium text-foreground">{item.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {item.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Required Documents */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <FileText className="h-6 w-6" />
                </div>
                <h2 className="text-xl font-semibold text-foreground">
                  Required Documents
                </h2>
              </div>
              <div className="space-y-4">
                {requiredDocuments.map((doc) => (
                  <div key={doc.title} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium text-foreground">{doc.title}</p>
                      <p className="text-sm text-muted-foreground">{doc.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Appeals */}
            <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-secondary/5 p-6 border border-border/50">
              <div className="flex items-start gap-4">
                <div className="shrink-0 w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                  <AlertCircle className="h-6 w-6" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-foreground mb-2">
                    What If My Application Is Rejected?
                  </h2>
                  <p className="text-muted-foreground mb-4">
                    You can appeal the decision within the specified timeframe.
                    Common reasons for rejection include:
                  </p>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Missing or incorrect documents</li>
                    <li>• Income verification issues</li>
                    <li>• Incomplete application form</li>
                    <li>• Previous funding at the same level</li>
                  </ul>
                  <p className="mt-4 text-foreground font-medium">
                    Our advisors can help you understand the reason and submit a
                    proper appeal.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Important Dates */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <Calendar className="h-5 w-5 text-primary" />
                <h3 className="font-semibold text-foreground">Important Dates</h3>
              </div>
              <div className="space-y-3">
                {importantDates.map((item) => (
                  <div key={item.event} className="flex justify-between py-2 border-b border-border/50 last:border-0">
                    <span className="text-sm text-muted-foreground">{item.event}</span>
                    <span className="text-sm font-medium text-foreground">{item.date}</span>
                  </div>
                ))}
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                * Dates may vary each year. Check the official NSFAS website for
                current dates.
              </p>
            </div>

            {/* Official Links */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">Official Links</h3>
              <div className="space-y-3">
                <a
                  href="https://www.nsfas.org.za"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                >
                  <span className="text-sm font-medium">NSFAS Website</span>
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                </a>
                <a
                  href="https://my.nsfas.org.za"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                >
                  <span className="text-sm font-medium">myNSFAS Portal</span>
                  <ExternalLink className="h-4 w-4 text-muted-foreground" />
                </a>
              </div>
            </div>

            {/* FAQ Teaser */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <div className="flex items-center gap-3 mb-4">
                <HelpCircle className="h-5 w-5 text-primary" />
                <h3 className="font-semibold text-foreground">Common Questions</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Have questions about NSFAS? Check our FAQ section for answers to
                common questions.
              </p>
              <Button asChild variant="outline" className="w-full rounded-xl bg-transparent">
                <Link href="/faq">View NSFAS FAQs</Link>
              </Button>
            </div>

            {/* Help Card */}
            <div className="rounded-2xl gradient-primary p-6 text-primary-foreground">
              <h3 className="font-semibold mb-2">Need Help With NSFAS?</h3>
              <p className="text-sm text-primary-foreground/90 mb-4">
                Our advisors have helped hundreds of learners successfully apply
                for NSFAS. Let us help you too — for free!
              </p>
              <Button
                asChild
                className="w-full bg-white text-primary hover:bg-white/90 rounded-xl"
              >
                <Link href="/clc/book-assistance">Book Free Session</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
