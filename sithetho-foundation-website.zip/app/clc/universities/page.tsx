"use client";

import { useState, useMemo } from "react";
import Link from "next/link";
import { PageHeader } from "@/components/ui/page-header";
import { Section } from "@/components/ui/section";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { universities, provinces } from "@/data/universities";
import { Search, MapPin, GraduationCap, ExternalLink, CheckCircle } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

const Loading = () => null;

export default function UniversitiesPage() {
  const [search, setSearch] = useState("");
  const [provinceFilter, setProvinceFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const searchParams = useSearchParams();

  const filteredUniversities = useMemo(() => {
    return universities.filter((uni) => {
      const matchSearch =
        !search ||
        uni.name.toLowerCase().includes(search.toLowerCase()) ||
        uni.shortName.toLowerCase().includes(search.toLowerCase()) ||
        uni.city.toLowerCase().includes(search.toLowerCase());
      const matchProvince =
        provinceFilter === "all" || uni.province === provinceFilter;
      const matchType = typeFilter === "all" || uni.type === typeFilter;
      return matchSearch && matchProvince && matchType;
    });
  }, [search, provinceFilter, typeFilter]);

  const publicCount = universities.filter((u) => u.type === "public").length;
  const privateCount = universities.filter((u) => u.type === "private").length;

  return (
    <>
      <Suspense fallback={<Loading />}>
        <PageHeader
          title="Universities"
          description="Explore public and private universities across South Africa. Find the right institution for your academic journey."
          logo="/assets/ndclc.png"
        />

        <Section variant="default">
          {/* Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{universities.length}</p>
              <p className="text-sm text-muted-foreground">Total Universities</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{publicCount}</p>
              <p className="text-sm text-muted-foreground">Public Universities</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{privateCount}</p>
              <p className="text-sm text-muted-foreground">Private Institutions</p>
            </div>
            <div className="rounded-2xl bg-card p-4 shadow-soft border border-border/50 text-center">
              <p className="text-2xl font-bold text-foreground">{provinces.length}</p>
              <p className="text-sm text-muted-foreground">Provinces Covered</p>
            </div>
          </div>

          {/* Filters */}
          <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50 mb-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Search universities..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-10 rounded-xl"
                />
              </div>
              <Select value={provinceFilter} onValueChange={setProvinceFilter}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="Province" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Provinces</SelectItem>
                  {provinces.map((province) => (
                    <SelectItem key={province} value={province}>
                      {province}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="rounded-xl">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="public">Public</SelectItem>
                  <SelectItem value="private">Private</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Results */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredUniversities.map((uni) => (
              <Link
                key={uni.id}
                href={`/clc/institution/${uni.slug}`}
                className="group rounded-2xl bg-card p-6 shadow-soft border border-border/50 card-hover"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span
                        className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                          uni.type === "public"
                            ? "bg-primary/10 text-primary"
                            : "bg-secondary/10 text-secondary"
                        }`}
                      >
                        {uni.type === "public" ? "Public" : "Private"}
                      </span>
                      {uni.nsfasAccredited && (
                        <span className="flex items-center gap-1 text-xs text-green-600">
                          <CheckCircle className="h-3 w-3" />
                          NSFAS
                        </span>
                      )}
                    </div>
                    <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
                      {uni.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{uni.shortName}</p>
                  </div>
                  <div className="shrink-0">
                    <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                      <GraduationCap className="h-6 w-6" />
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-4 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <MapPin className="h-4 w-4" />
                    {uni.city}, {uni.province}
                  </span>
                </div>

                <div className="mt-4 flex flex-wrap gap-2">
                  {uni.popularCourses.slice(0, 3).map((course) => (
                    <span
                      key={course}
                      className="px-2 py-1 text-xs bg-muted rounded-lg text-muted-foreground"
                    >
                      {course}
                    </span>
                  ))}
                  {uni.popularCourses.length > 3 && (
                    <span className="px-2 py-1 text-xs bg-muted rounded-lg text-muted-foreground">
                      +{uni.popularCourses.length - 3} more
                    </span>
                  )}
                </div>

                <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Min APS</p>
                    <p className="font-semibold text-foreground">{uni.minAPS}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Application Fee</p>
                    <p className="font-semibold text-foreground">{uni.applicationFee}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Deadline</p>
                    <p className="font-semibold text-foreground">{uni.applicationDeadline}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {filteredUniversities.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground">
                No universities found matching your criteria.
              </p>
              <Button
                variant="outline"
                className="mt-4 bg-transparent"
                onClick={() => {
                  setSearch("");
                  setProvinceFilter("all");
                  setTypeFilter("all");
                }}
              >
                Clear Filters
              </Button>
            </div>
          )}
        </Section>

        {/* Help Banner */}
        <Section variant="muted">
          <div className="rounded-3xl bg-card p-8 lg:p-12 shadow-soft border border-border/50 text-center">
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Need Help Choosing?
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-6">
              Our education advisors can help you understand which universities
              match your APS, subjects, and career goals.
            </p>
            <Button
              asChild
              className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8"
            >
              <Link href="/clc/book-assistance">Book Free Consultation</Link>
            </Button>
          </div>
        </Section>
      </Suspense>
    </>
  );
}
