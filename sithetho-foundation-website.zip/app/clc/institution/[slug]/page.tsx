import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { getUniversityBySlug, universities } from "@/data/universities";
import { getCollegeBySlug, colleges } from "@/data/colleges";
import {
  MapPin,
  Globe,
  Mail,
  Phone,
  Calendar,
  FileText,
  DollarSign,
  CheckCircle,
  ExternalLink,
  ArrowLeft,
  Home,
  Wallet,
} from "lucide-react";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
  const uniSlugs = universities.map((u) => ({ slug: u.slug }));
  const collegeSlugs = colleges.map((c) => ({ slug: c.slug }));
  return [...uniSlugs, ...collegeSlugs];
}

export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { slug } = await params;
  const university = getUniversityBySlug(slug);
  const college = getCollegeBySlug(slug);
  const institution = university || college;

  if (!institution) {
    return { title: "Institution Not Found" };
  }

  return {
    title: institution.name,
    description: institution.description,
  };
}

export default async function InstitutionPage({ params }: PageProps) {
  const { slug } = await params;
  const university = getUniversityBySlug(slug);
  const college = getCollegeBySlug(slug);
  const institution = university || college;

  if (!institution) {
    notFound();
  }

  const isUniversity = !!university;
  const minAPS = isUniversity ? university.minAPS : college?.minAPS;

  return (
    <>
      <PageHeader
        title={institution.name}
        description={institution.description}
        logo="/assets/ndclc.png"
      >
        <div className="flex flex-wrap justify-center gap-3 mt-4">
          <span
            className={`px-3 py-1 text-sm font-medium rounded-full ${
              institution.type === "public" || institution.type === "public-tvet"
                ? "bg-primary/20 text-primary"
                : "bg-secondary/20 text-secondary"
            }`}
          >
            {institution.type === "public"
              ? "Public University"
              : institution.type === "public-tvet"
                ? "Public TVET College"
                : "Private Institution"}
          </span>
          {institution.nsfasAccredited && (
            <span className="flex items-center gap-1 px-3 py-1 text-sm font-medium rounded-full bg-green-100 text-green-700">
              <CheckCircle className="h-4 w-4" />
              NSFAS Accredited
            </span>
          )}
        </div>
      </PageHeader>

      <Section variant="default">
        {/* Back link */}
        <Link
          href={isUniversity ? "/clc/universities" : "/clc/tvet-colleges"}
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to {isUniversity ? "Universities" : "Colleges"}
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Info */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Quick Information
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="font-medium text-foreground">
                      {institution.city}, {institution.province}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <DollarSign className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Application Fee</p>
                    <p className="font-medium text-foreground">
                      {institution.applicationFee}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Application Deadline</p>
                    <p className="font-medium text-foreground">
                      {institution.applicationDeadline}
                    </p>
                  </div>
                </div>
                {minAPS && (
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center">
                      <FileText className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Minimum APS</p>
                      <p className="font-medium text-foreground">{minAPS} points</p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Application Steps */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                How to Apply
              </h2>
              <div className="space-y-4">
                {[
                  {
                    step: 1,
                    title: "Visit the Official Website",
                    description: `Go to ${institution.website} and navigate to the admissions or applications section.`,
                  },
                  {
                    step: 2,
                    title: "Create an Account",
                    description:
                      "Register for an online application account using your email address and personal details.",
                  },
                  {
                    step: 3,
                    title: "Complete the Application Form",
                    description:
                      "Fill in all required information including personal details, academic history, and programme choice.",
                  },
                  {
                    step: 4,
                    title: "Upload Required Documents",
                    description:
                      "Upload certified copies of all required documents (see list below).",
                  },
                  {
                    step: 5,
                    title: "Pay Application Fee",
                    description: `Pay the application fee of ${institution.applicationFee} using the payment methods provided.`,
                  },
                  {
                    step: 6,
                    title: "Submit and Track",
                    description:
                      "Submit your application and use the tracking system to monitor your application status.",
                  },
                ].map((item) => (
                  <div key={item.step} className="flex gap-4">
                    <div className="shrink-0 w-8 h-8 rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-sm font-bold">
                      {item.step}
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">{item.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">
                        {item.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Required Documents */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Required Documents
              </h2>
              <ul className="space-y-3">
                {institution.requiredDocuments.map((doc) => (
                  <li key={doc} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-foreground">{doc}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Popular Courses */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h2 className="text-xl font-semibold text-foreground mb-4">
                Popular Programmes
              </h2>
              <div className="flex flex-wrap gap-2">
                {institution.popularCourses.map((course) => (
                  <span
                    key={course}
                    className="px-3 py-2 text-sm bg-muted rounded-xl text-foreground"
                  >
                    {course}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">Contact</h3>
              <div className="space-y-4">
                <a
                  href={institution.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                >
                  <Globe className="h-5 w-5" />
                  <span className="text-sm truncate">{institution.website}</span>
                </a>
                {institution.contactEmail && (
                  <a
                    href={`mailto:${institution.contactEmail}`}
                    className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Mail className="h-5 w-5" />
                    <span className="text-sm">{institution.contactEmail}</span>
                  </a>
                )}
                {institution.contactPhone && (
                  <a
                    href={`tel:${institution.contactPhone}`}
                    className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Phone className="h-5 w-5" />
                    <span className="text-sm">{institution.contactPhone}</span>
                  </a>
                )}
              </div>
              <Button
                asChild
                className="w-full mt-6 gradient-primary text-primary-foreground hover:opacity-90 rounded-xl"
              >
                <a
                  href={institution.website}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Visit Website
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            </div>

            {/* Quick Links */}
            <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
              <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
              <div className="space-y-3">
                {institution.nsfasAccredited && (
                  <Link
                    href="/clc/nsfas"
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                  >
                    <Wallet className="h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">NSFAS Support</span>
                  </Link>
                )}
                {"accommodationLink" in institution && institution.accommodationLink && (
                  <a
                    href={institution.accommodationLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                  >
                    <Home className="h-5 w-5 text-primary" />
                    <span className="text-sm font-medium">Accommodation</span>
                  </a>
                )}
                <Link
                  href="/clc/aps-calculator"
                  className="flex items-center gap-3 p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                >
                  <FileText className="h-5 w-5 text-primary" />
                  <span className="text-sm font-medium">Calculate Your APS</span>
                </Link>
              </div>
            </div>

            {/* Help Card */}
            <div className="rounded-2xl gradient-primary p-6 text-primary-foreground">
              <h3 className="font-semibold mb-2">Need Help Applying?</h3>
              <p className="text-sm text-primary-foreground/90 mb-4">
                Our advisors can guide you through the entire application process
                for free.
              </p>
              <Button
                asChild
                className="w-full bg-white text-primary hover:bg-white/90 rounded-xl"
              >
                <Link href="/clc/book-assistance">Book Free Session</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>
    </>
  );
}
