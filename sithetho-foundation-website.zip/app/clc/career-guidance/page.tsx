"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { careers, careerClusters, getCareerRecommendations, type Career } from "@/data/careers";
import { subjectList } from "@/data/aps";
import {
  Compass,
  TrendingUp,
  DollarSign,
  GraduationCap,
  Briefcase,
  ArrowRight,
  Plus,
  Trash2,
  Search,
  Filter,
} from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense } from "react";

interface SubjectEntry {
  id: string;
  name: string;
  mark: number;
}

const Loading = () => null;

export default function CareerGuidancePage() {
  const [subjects, setSubjects] = useState<SubjectEntry[]>([
    { id: "1", name: "", mark: 0 },
    { id: "2", name: "", mark: 0 },
    { id: "3", name: "", mark: 0 },
  ]);
  const [recommendations, setRecommendations] = useState<Career[]>([]);
  const [selectedCluster, setSelectedCluster] = useState<string>("all");
  const [showResults, setShowResults] = useState(false);
  const searchParams = useSearchParams();

  const addSubject = () => {
    setSubjects([
      ...subjects,
      { id: Date.now().toString(), name: "", mark: 0 },
    ]);
  };

  const removeSubject = (id: string) => {
    if (subjects.length > 1) {
      setSubjects(subjects.filter((s) => s.id !== id));
    }
  };

  const updateSubject = (id: string, field: "name" | "mark", value: string | number) => {
    setSubjects(
      subjects.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const findCareers = () => {
    const validSubjects = subjects.filter((s) => s.name && s.mark > 0);
    if (validSubjects.length === 0) {
      alert("Please enter at least one subject with a mark.");
      return;
    }
    const recs = getCareerRecommendations(validSubjects);
    setRecommendations(recs);
    setShowResults(true);
  };

  const filteredCareers = selectedCluster === "all"
    ? (showResults ? recommendations : careers)
    : (showResults ? recommendations : careers).filter(c => c.cluster === selectedCluster);

  const getDemandColor = (level: string) => {
    switch (level) {
      case "high":
        return "bg-green-100 text-green-700";
      case "medium":
        return "bg-yellow-100 text-yellow-700";
      case "low":
        return "bg-red-100 text-red-700";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getClusterIcon = (cluster: string) => {
    switch (cluster) {
      case "science":
        return "bg-blue-100 text-blue-700";
      case "commerce":
        return "bg-green-100 text-green-700";
      case "arts":
        return "bg-purple-100 text-purple-700";
      case "technical":
        return "bg-orange-100 text-orange-700";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  return (
    <Suspense fallback={<Loading />}>
      <>
        <PageHeader
          title="Career Guidance"
          description="Discover career paths that match your subjects, interests, and strengths. Explore salary ranges, demand levels, and study options."
          logo="/assets/ndclc.png"
        />

        <Section variant="default">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Subject Input */}
              <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
                <h2 className="text-xl font-semibold text-foreground mb-2 flex items-center gap-2">
                  <Compass className="h-5 w-5 text-primary" />
                  Find Careers Based on Your Subjects
                </h2>
                <p className="text-sm text-muted-foreground mb-6">
                  Enter your subjects and marks to get personalized career recommendations.
                </p>

                <div className="space-y-4">
                  {subjects.map((subject, index) => (
                    <div key={subject.id} className="flex items-center gap-3">
                      <span className="w-6 text-sm text-muted-foreground">
                        {index + 1}.
                      </span>
                      <Select
                        value={subject.name}
                        onValueChange={(value) => updateSubject(subject.id, "name", value)}
                      >
                        <SelectTrigger className="flex-1 rounded-xl">
                          <SelectValue placeholder="Select subject" />
                        </SelectTrigger>
                        <SelectContent>
                          {subjectList.filter(s => s !== "Life Orientation").map((s) => (
                            <SelectItem key={s} value={s}>
                              {s}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className="relative w-24">
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="Mark"
                          value={subject.mark || ""}
                          onChange={(e) =>
                            updateSubject(
                              subject.id,
                              "mark",
                              Math.min(100, Math.max(0, parseInt(e.target.value) || 0))
                          }
                          className="rounded-xl pr-8"
                        />
                        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">
                          %
                        </span>
                      </div>
                      {subjects.length > 1 && (
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeSubject(subject.id)}
                          className="shrink-0"
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      )}
                    </div>
                  ))}
                </div>

                <div className="mt-6 flex flex-wrap gap-3">
                  <Button variant="outline" onClick={addSubject} className="rounded-xl bg-transparent">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Subject
                  </Button>
                  <Button
                    onClick={findCareers}
                    className="gradient-primary text-primary-foreground hover:opacity-90 rounded-xl"
                  >
                    <Search className="h-4 w-4 mr-2" />
                    Find Matching Careers
                  </Button>
                </div>
              </div>

              {/* Filter by Cluster */}
              <div className="flex items-center gap-4 flex-wrap">
                <div className="flex items-center gap-2">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground">Filter:</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setSelectedCluster("all")}
                    className={`px-3 py-1.5 text-sm rounded-full transition-colors ${
                      selectedCluster === "all"
                        ? "gradient-primary text-primary-foreground"
                        : "bg-muted text-muted-foreground hover:bg-accent"
                    }`}
                  >
                    All Careers
                  </button>
                  {careerClusters.map((cluster) => (
                    <button
                      key={cluster.id}
                      onClick={() => setSelectedCluster(cluster.id)}
                      className={`px-3 py-1.5 text-sm rounded-full transition-colors ${
                        selectedCluster === cluster.id
                          ? "gradient-primary text-primary-foreground"
                          : "bg-muted text-muted-foreground hover:bg-accent"
                      }`}
                    >
                      {cluster.name}
                    </button>
                  ))}
                </div>
              </div>

              {/* Results Header */}
              {showResults && recommendations.length > 0 && (
                <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-secondary/5 p-4 border border-border/50">
                  <p className="text-sm text-foreground">
                    Found <span className="font-semibold">{filteredCareers.length}</span> careers
                    matching your subjects. Showing careers sorted by demand level.
                  </p>
                </div>
              )}

              {/* Career Cards */}
              <div className="space-y-4">
                {filteredCareers.map((career) => (
                  <div
                    key={career.id}
                    className="rounded-2xl bg-card p-6 shadow-soft border border-border/50 card-hover"
                  >
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`px-2 py-0.5 text-xs font-medium rounded-full capitalize ${getClusterIcon(career.cluster)}`}>
                            {career.cluster}
                          </span>
                          <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${getDemandColor(career.demandLevel)}`}>
                            {career.demandLevel} demand
                          </span>
                        </div>
                        <h3 className="text-lg font-semibold text-foreground">
                          {career.title}
                        </h3>
                      </div>
                      <div className="shrink-0 w-12 h-12 rounded-xl gradient-primary flex items-center justify-center text-primary-foreground">
                        <Briefcase className="h-6 w-6" />
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground mb-4">
                      {career.description}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                          <GraduationCap className="h-3 w-3" />
                          Required Subjects
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {career.requiredSubjects.map((s) => (
                            <span
                              key={s}
                              className="px-2 py-0.5 text-xs bg-primary/10 text-primary rounded-lg"
                            >
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          Min APS Required
                        </p>
                        <p className="font-semibold text-foreground">{career.minAPS} points</p>
                      </div>
                    </div>

                    <div className="pt-4 border-t border-border/50">
                      <p className="text-xs text-muted-foreground mb-2 flex items-center gap-1">
                        <DollarSign className="h-3 w-3" />
                        Salary Range (Annual)
                      </p>
                      <div className="grid grid-cols-3 gap-2">
                        <div className="text-center p-2 rounded-lg bg-muted">
                          <p className="text-xs text-muted-foreground">Entry</p>
                          <p className="text-sm font-medium text-foreground">
                            {career.salaryRange.entry}
                          </p>
                        </div>
                        <div className="text-center p-2 rounded-lg bg-muted">
                          <p className="text-xs text-muted-foreground">Mid</p>
                          <p className="text-sm font-medium text-foreground">
                            {career.salaryRange.mid}
                          </p>
                        </div>
                        <div className="text-center p-2 rounded-lg bg-muted">
                          <p className="text-xs text-muted-foreground">Senior</p>
                          <p className="text-sm font-medium text-foreground">
                            {career.salaryRange.senior}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4">
                      <p className="text-xs text-muted-foreground mb-2">Study Paths:</p>
                      <p className="text-sm text-foreground">
                        {career.studyPaths.join(" → ")}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {filteredCareers.length === 0 && (
                <div className="text-center py-12 rounded-2xl bg-card border border-border/50">
                  <p className="text-muted-foreground">
                    No careers found matching your criteria.
                  </p>
                  <Button
                    variant="outline"
                    className="mt-4 bg-transparent"
                    onClick={() => {
                      setSelectedCluster("all");
                      setShowResults(false);
                    }}
                  >
                    Show All Careers
                  </Button>
                </div>
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Career Clusters */}
              <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
                <h3 className="font-semibold text-foreground mb-4">Career Clusters</h3>
                <div className="space-y-3">
                  {careerClusters.map((cluster) => (
                    <button
                      key={cluster.id}
                      onClick={() => setSelectedCluster(cluster.id)}
                      className={`w-full text-left p-3 rounded-xl transition-colors ${
                        selectedCluster === cluster.id
                          ? "bg-primary/10 border border-primary/30"
                          : "bg-muted hover:bg-accent"
                      }`}
                    >
                      <p className="font-medium text-foreground text-sm">
                        {cluster.name}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {cluster.description}
                      </p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Help Card */}
              <div className="rounded-2xl gradient-primary p-6 text-primary-foreground">
                <h3 className="font-semibold mb-2">Need Personalized Guidance?</h3>
                <p className="text-sm text-primary-foreground/90 mb-4">
                  Our advisors can help you explore career options based on your unique
                  interests, strengths, and circumstances.
                </p>
                <Button
                  asChild
                  className="w-full bg-white text-primary hover:bg-white/90 rounded-xl"
                >
                  <Link href="/clc/book-assistance">Book Free Session</Link>
                </Button>
              </div>

              {/* Quick Links */}
              <div className="rounded-2xl bg-card p-6 shadow-soft border border-border/50">
                <h3 className="font-semibold text-foreground mb-4">Related Tools</h3>
                <div className="space-y-3">
                  <Link
                    href="/clc/aps-calculator"
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                  >
                    <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center text-primary-foreground">
                      <TrendingUp className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium">APS Calculator</span>
                  </Link>
                  <Link
                    href="/clc/universities"
                    className="flex items-center gap-3 p-3 rounded-xl bg-muted hover:bg-accent transition-colors"
                  >
                    <div className="w-8 h-8 rounded-lg gradient-primary flex items-center justify-center text-primary-foreground">
                      <GraduationCap className="h-4 w-4" />
                    </div>
                    <span className="text-sm font-medium">Browse Universities</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </Section>
      </>
    </Suspense>
  );
}
