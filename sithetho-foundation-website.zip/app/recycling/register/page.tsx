import { Metadata } from "next";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { GoogleFormEmbed } from "@/components/ui/google-form-embed";
import { Card, CardContent } from "@/components/ui/card";
import { CheckCircle2, School, Building2, Leaf, Award } from "lucide-react";

export const metadata: Metadata = {
  title: "Register for Recycling",
  description: "Register your school or business to participate in our community recycling program.",
};

const benefits = [
  {
    icon: Leaf,
    title: "Environmental Impact",
    description: "Contribute to a cleaner community and reduce landfill waste.",
  },
  {
    icon: Award,
    title: "Earn Rewards",
    description: "Accumulate points for certificates and recognition.",
  },
  {
    icon: School,
    title: "Education Support",
    description: "Your recycling directly funds free education programs.",
  },
];

const steps = [
  "Complete the registration form below",
  "Our team will contact you within 48 hours",
  "Schedule your first collection date",
  "Start collecting recyclables and earning rewards",
];

export default function RecyclingRegisterPage() {
  return (
    <>
      <PageHeader
        title="Register for Recycling"
        subtitle="Join our network of schools and businesses committed to sustainable recycling."
        logoSrc="/assets/ndr.png"
        logoAlt="New Dawn Recycling Logo"
      />

      <Section>
        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Benefits sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-0 shadow-soft">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                    <School className="w-5 h-5 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-foreground">For Schools</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Educational institutions of all sizes can participate. We provide collection bins
                  and educational materials to help students learn about recycling.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-soft">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center">
                    <Building2 className="w-5 h-5 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-foreground">For Businesses</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Align your business with sustainable practices. Our corporate recycling program
                  helps you meet CSR goals while supporting community education.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-soft bg-gradient-to-br from-green-50 to-emerald-50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-foreground mb-4">Registration Steps</h3>
                <ul className="space-y-3">
                  {steps.map((step, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="w-6 h-6 rounded-full bg-green-500 text-white flex items-center justify-center text-xs font-medium shrink-0 mt-0.5">
                        {index + 1}
                      </div>
                      <span className="text-sm text-muted-foreground">{step}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <div className="space-y-4">
              {benefits.map((benefit) => (
                <div key={benefit.title} className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center shrink-0">
                    <benefit.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground text-sm">{benefit.title}</h4>
                    <p className="text-xs text-muted-foreground">{benefit.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-soft-lg">
              <CardContent className="p-6 md:p-8">
                <h2 className="text-xl font-semibold text-foreground mb-6">Registration Form</h2>
                <GoogleFormEmbed
                  formUrl="https://docs.google.com/forms/d/e/YOUR_RECYCLING_REGISTER_FORM_ID/viewform"
                  title="Recycling Registration Form"
                  height={800}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </Section>
    </>
  );
}
