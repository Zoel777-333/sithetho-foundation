"use client";

import { useState, useEffect, useRef } from "react";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
  Recycle,
  TreePine,
  Droplets,
  Zap,
  School,
  Building2,
  TrendingUp,
  ArrowRight,
  Leaf,
} from "lucide-react";
import { impactStats, recyclingStats } from "@/data/site";

function AnimatedCounter({
  end,
  suffix = "",
  duration = 2000,
}: {
  end: number;
  suffix?: string;
  duration?: number;
}) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [isVisible, end, duration]);

  return (
    <span ref={ref} className="tabular-nums">
      {count.toLocaleString()}
      {suffix}
    </span>
  );
}

const environmentalImpact = [
  {
    icon: TreePine,
    value: 12,
    suffix: "",
    label: "Trees Saved",
    description: "Through paper recycling efforts",
    color: "from-green-500 to-emerald-600",
  },
  {
    icon: Droplets,
    value: 5000,
    suffix: "L",
    label: "Water Saved",
    description: "By recycling plastic materials",
    color: "from-blue-500 to-cyan-600",
  },
  {
    icon: Zap,
    value: 850,
    suffix: "kWh",
    label: "Energy Saved",
    description: "Through aluminum can recycling",
    color: "from-amber-500 to-orange-600",
  },
  {
    icon: Leaf,
    value: 1200,
    suffix: "kg",
    label: "CO2 Prevented",
    description: "Greenhouse gas emissions avoided",
    color: "from-teal-500 to-green-600",
  },
];

const monthlyData = [
  { month: "Jan", paper: 180, plastic: 120, cans: 80 },
  { month: "Feb", paper: 220, plastic: 150, cans: 95 },
  { month: "Mar", paper: 280, plastic: 180, cans: 110 },
  { month: "Apr", paper: 320, plastic: 200, cans: 130 },
  { month: "May", paper: 380, plastic: 240, cans: 150 },
  { month: "Jun", paper: 420, plastic: 280, cans: 170 },
];

export default function ImpactPage() {
  return (
    <>
      <PageHeader
        title="Our Impact"
        subtitle="Track our collective progress toward a cleaner, greener community."
        logoSrc="/assets/ndr.png"
        logoAlt="New Dawn Recycling Logo"
      />

      {/* Main Stats */}
      <Section>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {[
            {
              icon: Recycle,
              value: recyclingStats.totalWasteRecycled,
              suffix: "kg",
              label: "Total Waste Recycled",
              color: "gradient-primary",
            },
            {
              icon: School,
              value: recyclingStats.partnerSchools,
              suffix: "+",
              label: "Partner Schools",
              color: "bg-blue-500",
            },
            {
              icon: Building2,
              value: recyclingStats.partnerBusinesses,
              suffix: "+",
              label: "Partner Businesses",
              color: "bg-purple-500",
            },
            {
              icon: TrendingUp,
              value: 45,
              suffix: "%",
              label: "Monthly Growth",
              color: "bg-green-500",
            },
          ].map((stat, index) => (
            <Card
              key={stat.label}
              className="border-0 shadow-soft-lg card-hover text-center"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div
                  className={`w-14 h-14 rounded-2xl ${stat.color} flex items-center justify-center mx-auto mb-4`}
                >
                  <stat.icon className="w-7 h-7 text-white" />
                </div>
                <div className="text-3xl md:text-4xl font-bold text-foreground mb-1">
                  <AnimatedCounter end={stat.value} suffix={stat.suffix} />
                </div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Environmental Impact */}
      <Section className="bg-gradient-to-br from-green-50/50 to-emerald-50/50">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Environmental Impact
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Every recyclable item makes a difference. Here is what our collective efforts have achieved
            for the environment.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {environmentalImpact.map((item, index) => (
            <Card
              key={item.label}
              className="border-0 shadow-soft card-hover overflow-hidden"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className={`h-1 bg-gradient-to-r ${item.color}`} />
              <CardContent className="p-6 text-center">
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center mx-auto mb-4`}
                >
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-foreground mb-1">
                  <AnimatedCounter end={item.value} suffix={item.suffix} />
                </div>
                <h3 className="font-semibold text-foreground text-sm mb-1">{item.label}</h3>
                <p className="text-xs text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Monthly Progress Chart */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Monthly Collection Progress
            </h2>
            <p className="text-muted-foreground">
              Tracking our recycling collection growth over the past months.
            </p>
          </div>

          <Card className="border-0 shadow-soft-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-6 mb-6 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-blue-500" />
                  <span className="text-sm text-muted-foreground">Paper</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-green-500" />
                  <span className="text-sm text-muted-foreground">Plastic</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 rounded bg-amber-500" />
                  <span className="text-sm text-muted-foreground">Cans</span>
                </div>
              </div>

              {/* Simple bar chart visualization */}
              <div className="space-y-4">
                {monthlyData.map((data) => (
                  <div key={data.month} className="flex items-center gap-4">
                    <span className="w-8 text-sm font-medium text-muted-foreground">
                      {data.month}
                    </span>
                    <div className="flex-1 flex gap-1 h-8">
                      <div
                        className="bg-blue-500 rounded-l transition-all duration-1000"
                        style={{ width: `${(data.paper / 500) * 100}%` }}
                      />
                      <div
                        className="bg-green-500 transition-all duration-1000"
                        style={{ width: `${(data.plastic / 500) * 100}%` }}
                      />
                      <div
                        className="bg-amber-500 rounded-r transition-all duration-1000"
                        style={{ width: `${(data.cans / 500) * 100}%` }}
                      />
                    </div>
                    <span className="w-16 text-sm text-muted-foreground text-right">
                      {data.paper + data.plastic + data.cans}kg
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Education Connection */}
      <Section className="bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-soft-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                    Supporting Education
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Every kilogram of recyclables collected generates funds that directly support our
                    free education programs. Your recycling helps learners access university
                    applications, career guidance, and NSFAS support.
                  </p>
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="text-center p-4 bg-primary/5 rounded-xl">
                      <div className="text-2xl font-bold text-primary">
                        <AnimatedCounter end={impactStats.learnersAssisted} suffix="+" />
                      </div>
                      <p className="text-xs text-muted-foreground">Learners Assisted</p>
                    </div>
                    <div className="text-center p-4 bg-secondary/5 rounded-xl">
                      <div className="text-2xl font-bold text-secondary">
                        <AnimatedCounter end={impactStats.schoolsPartnered} suffix="+" />
                      </div>
                      <p className="text-xs text-muted-foreground">Schools Reached</p>
                    </div>
                  </div>
                  <Link href="/clc">
                    <Button className="gradient-primary">
                      Learn About Our Education Programs
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                </div>
                <div className="relative h-64 md:h-auto gradient-primary flex items-center justify-center">
                  <div className="text-center text-white">
                    <div className="text-5xl font-bold mb-2">100%</div>
                    <p className="text-white/80">Free Services</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* CTA */}
      <Section>
        <div className="max-w-3xl mx-auto text-center">
          <Recycle className="w-16 h-16 mx-auto mb-6 text-primary/60" />
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Be Part of the Impact
          </h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Join our growing community of schools and businesses making a difference through
            sustainable recycling.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/recycling/register">
              <Button size="lg" className="gradient-primary w-full sm:w-auto">
                Register Your Organization
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link href="/recycling">
              <Button size="lg" variant="outline" className="w-full sm:w-auto bg-transparent">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
