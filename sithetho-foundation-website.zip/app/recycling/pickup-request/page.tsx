import { Metadata } from "next";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { GoogleFormEmbed } from "@/components/ui/google-form-embed";
import { Card, CardContent } from "@/components/ui/card";
import { Truck, Calendar, Clock, MapPin, Package, AlertCircle } from "lucide-react";

export const metadata: Metadata = {
  title: "Request Pickup",
  description: "Schedule a monthly recycling pickup for your school or business.",
};

const guidelines = [
  {
    icon: Package,
    title: "Prepare Materials",
    description: "Sort recyclables into paper, plastic, and cans. Keep them clean and dry.",
  },
  {
    icon: Calendar,
    title: "Monthly Schedule",
    description: "Pickups are scheduled once per month. Request at least 5 days in advance.",
  },
  {
    icon: Clock,
    title: "Collection Times",
    description: "Collections happen between 8:00 AM and 4:00 PM on weekdays.",
  },
  {
    icon: MapPin,
    title: "Accessible Location",
    description: "Ensure materials are in an accessible location for our collection team.",
  },
];

export default function PickupRequestPage() {
  return (
    <>
      <PageHeader
        title="Request a Pickup"
        subtitle="Schedule your monthly recycling collection. We will come to you!"
        logoSrc="/assets/ndr.png"
        logoAlt="New Dawn Recycling Logo"
      />

      <Section>
        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {/* Guidelines sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="border-0 shadow-soft">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-xl gradient-primary flex items-center justify-center">
                    <Truck className="w-5 h-5 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground">Collection Service</h3>
                </div>
                <p className="text-sm text-muted-foreground">
                  Our collection team serves the Mdantsane and East London areas. If you are
                  outside this area, please contact us to discuss options.
                </p>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-soft bg-gradient-to-br from-blue-50 to-indigo-50">
              <CardContent className="p-6">
                <h3 className="font-semibold text-foreground mb-4">Pickup Guidelines</h3>
                <div className="space-y-4">
                  {guidelines.map((guideline) => (
                    <div key={guideline.title} className="flex items-start gap-3">
                      <div className="w-8 h-8 rounded-lg bg-white shadow-sm flex items-center justify-center shrink-0">
                        <guideline.icon className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium text-foreground text-sm">{guideline.title}</h4>
                        <p className="text-xs text-muted-foreground">{guideline.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="border-0 shadow-soft border-l-4 border-l-amber-400">
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-foreground text-sm mb-1">Not Registered Yet?</h4>
                    <p className="text-xs text-muted-foreground">
                      You need to be a registered partner to request pickups.{" "}
                      <a href="/recycling/register" className="text-primary hover:underline">
                        Register here
                      </a>{" "}
                      first.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Form */}
          <div className="lg:col-span-2">
            <Card className="border-0 shadow-soft-lg">
              <CardContent className="p-6 md:p-8">
                <h2 className="text-xl font-semibold text-foreground mb-2">Pickup Request Form</h2>
                <p className="text-sm text-muted-foreground mb-6">
                  Fill in the details below and we will schedule your collection.
                </p>
                <GoogleFormEmbed
                  formUrl="https://docs.google.com/forms/d/e/YOUR_PICKUP_REQUEST_FORM_ID/viewform"
                  title="Pickup Request Form"
                  height={700}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </Section>
    </>
  );
}
