import { Metadata } from "next";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import {
  Award,
  Star,
  Trophy,
  Medal,
  Target,
  Gift,
  ArrowRight,
  CheckCircle2,
  Sparkles,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Rewards Program",
  description: "Learn about our recycling rewards program - earn points, certificates, and recognition.",
};

const tiers = [
  {
    name: "Bronze",
    icon: Medal,
    points: "0 - 500",
    color: "from-amber-600 to-amber-700",
    benefits: [
      "Monthly recycling certificate",
      "Recognition on our website",
      "Quarterly progress report",
    ],
  },
  {
    name: "Silver",
    icon: Star,
    points: "501 - 1500",
    color: "from-slate-400 to-slate-500",
    benefits: [
      "All Bronze benefits",
      "Featured partner spotlight",
      "Educational workshop access",
      "Social media recognition",
    ],
  },
  {
    name: "Gold",
    icon: Trophy,
    points: "1501+",
    color: "from-yellow-500 to-amber-500",
    benefits: [
      "All Silver benefits",
      "Annual sustainability award",
      "Priority collection scheduling",
      "Exclusive partner events",
      "Custom sustainability report",
    ],
  },
];

const pointsSystem = [
  { material: "Paper (per kg)", points: 2 },
  { material: "Plastic (per kg)", points: 3 },
  { material: "Cans (per kg)", points: 4 },
  { material: "Referral bonus", points: 50 },
  { material: "Monthly consistency", points: 25 },
];

export default function RewardsPage() {
  return (
    <>
      <PageHeader
        title="Rewards Program"
        subtitle="Earn recognition for your commitment to sustainability and community education."
        logoSrc="/assets/ndr.png"
        logoAlt="New Dawn Recycling Logo"
      />

      {/* How It Works */}
      <Section>
        <div className="max-w-4xl mx-auto text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How You Earn Points
          </h2>
          <p className="text-muted-foreground">
            Every kilogram of recyclable material you contribute earns you points toward rewards
            and recognition.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="border-0 shadow-soft-lg">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-foreground">Points System</h3>
              </div>
              <div className="space-y-3">
                {pointsSystem.map((item) => (
                  <div
                    key={item.material}
                    className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                  >
                    <span className="text-muted-foreground">{item.material}</span>
                    <span className="font-semibold text-primary">{item.points} pts</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-soft-lg bg-gradient-to-br from-primary/5 to-secondary/5">
            <CardContent className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl bg-white shadow-sm flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground">Bonus Opportunities</h3>
              </div>
              <ul className="space-y-3">
                {[
                  "Refer another school or business",
                  "Maintain monthly contributions",
                  "Participate in community events",
                  "Achieve collection milestones",
                  "Engage students in recycling education",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                    <span className="text-muted-foreground text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Reward Tiers */}
      <Section className="bg-muted/30">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Reward Tiers</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Progress through tiers to unlock additional benefits and recognition.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {tiers.map((tier, index) => (
            <Card
              key={tier.name}
              className={`border-0 shadow-soft-lg card-hover overflow-hidden ${
                index === 2 ? "ring-2 ring-yellow-400 ring-offset-2" : ""
              }`}
            >
              <div className={`h-2 bg-gradient-to-r ${tier.color}`} />
              <CardContent className="p-6">
                <div className="text-center mb-6">
                  <div
                    className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${tier.color} flex items-center justify-center mx-auto mb-4`}
                  >
                    <tier.icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground">{tier.name}</h3>
                  <p className="text-sm text-muted-foreground">{tier.points} points</p>
                </div>
                <ul className="space-y-2">
                  {tier.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                      <span className="text-sm text-muted-foreground">{benefit}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Certificates */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-soft-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center mb-6">
                    <Award className="w-7 h-7 text-white" />
                  </div>
                  <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                    Certificates & Recognition
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Every participating school and business receives official certificates
                    recognizing their contribution to sustainability and community education. Display
                    your commitment proudly!
                  </p>
                  <ul className="space-y-2 mb-6">
                    {[
                      "Monthly participation certificates",
                      "Milestone achievement awards",
                      "Annual sustainability recognition",
                      "Community impact reports",
                    ].map((item) => (
                      <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CheckCircle2 className="w-4 h-4 text-green-500" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="relative h-64 md:h-auto bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center">
                  <Award className="w-32 h-32 text-primary/20" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* CTA */}
      <Section className="gradient-primary text-white">
        <div className="max-w-3xl mx-auto text-center">
          <Gift className="w-16 h-16 mx-auto mb-6 text-white/80" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Start Earning Today</h2>
          <p className="text-white/80 mb-8 max-w-xl mx-auto">
            Register your school or business and begin your journey toward sustainability rewards
            and community recognition.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/recycling/register">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 w-full sm:w-auto">
                Register Now
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link href="/recycling/impact">
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 w-full sm:w-auto bg-transparent"
              >
                View Impact
              </Button>
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
