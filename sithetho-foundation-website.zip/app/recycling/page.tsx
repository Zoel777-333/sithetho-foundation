"use client";

import { useState, useEffect, useRef } from "react";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import {
  Recycle,
  Leaf,
  School,
  Building2,
  Truck,
  Award,
  BarChart3,
  ArrowRight,
  CheckCircle2,
  Newspaper,
  Package,
  Cylinder,
} from "lucide-react";

const wasteTypes = [
  {
    icon: Newspaper,
    name: "Paper",
    description: "Newspapers, magazines, cardboard, office paper",
    color: "from-blue-500 to-blue-600",
  },
  {
    icon: Package,
    name: "Plastic",
    description: "Bottles, containers, packaging materials",
    color: "from-green-500 to-green-600",
  },
  {
    icon: Cylinder,
    name: "Cans",
    description: "Aluminum cans, tin cans, metal containers",
    color: "from-amber-500 to-amber-600",
  },
];

const benefits = [
  {
    icon: Leaf,
    title: "Environmental Impact",
    description: "Reduce landfill waste and protect our natural resources for future generations.",
  },
  {
    icon: School,
    title: "Education Connection",
    description: "Recycling revenue supports our free education programs for learners.",
  },
  {
    icon: Award,
    title: "Rewards Program",
    description: "Earn points, certificates, and recognition for your recycling contributions.",
  },
  {
    icon: Building2,
    title: "Community Building",
    description: "Join a network of schools and businesses committed to sustainability.",
  },
];

const services = [
  {
    icon: Truck,
    title: "Monthly Collection",
    description: "Regular scheduled pickups from your school or business premises.",
    href: "/recycling/pickup-request",
    cta: "Request Pickup",
  },
  {
    icon: School,
    title: "School Programs",
    description: "Partner with us for educational recycling initiatives in your school.",
    href: "/recycling/register",
    cta: "Register School",
  },
  {
    icon: Building2,
    title: "Business Partners",
    description: "Corporate recycling solutions that align with your CSR goals.",
    href: "/recycling/register",
    cta: "Partner With Us",
  },
  {
    icon: Award,
    title: "Rewards & Recognition",
    description: "Earn points and certificates for your recycling contributions.",
    href: "/recycling/rewards",
    cta: "Learn More",
  },
];

function AnimatedCounter({ end, suffix = "", duration = 2000 }: { end: number; suffix?: string; duration?: number }) {
  const [count, setCount] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!isVisible) return;

    let startTime: number;
    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const progress = Math.min((currentTime - startTime) / duration, 1);
      setCount(Math.floor(progress * end));
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };
    requestAnimationFrame(animate);
  }, [isVisible, end, duration]);

  return (
    <span ref={ref} className="tabular-nums">
      {count.toLocaleString()}{suffix}
    </span>
  );
}

export default function RecyclingPage() {
  return (
    <>
      <PageHeader
        title="Recycling Division"
        subtitle="Building cleaner communities through sustainable recycling initiatives that support education."
        logoSrc="/assets/ndr.png"
        logoAlt="New Dawn Recycling Logo"
      />

      {/* Why Recycling + Education */}
      <Section className="bg-gradient-to-br from-green-50/50 to-emerald-50/50">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 text-balance">
            Why Recycling Supports Education
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every recyclable item collected generates funds that directly support our free education
            programs. When you recycle with us, you are not just helping the environment — you are
            helping a learner access university, college, or career guidance they could not
            otherwise afford.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => (
            <Card
              key={benefit.title}
              className="card-hover border-0 shadow-soft bg-card/80 backdrop-blur-sm"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6 text-center">
                <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{benefit.title}</h3>
                <p className="text-sm text-muted-foreground">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* What We Collect */}
      <Section>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What We Collect
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            We accept the following recyclable materials from schools and businesses.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {wasteTypes.map((type, index) => (
            <Card
              key={type.name}
              className="card-hover border-0 shadow-soft-lg overflow-hidden"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-8 text-center">
                <div className={`w-20 h-20 rounded-3xl bg-gradient-to-br ${type.color} flex items-center justify-center mx-auto mb-6`}>
                  <type.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{type.name}</h3>
                <p className="text-muted-foreground">{type.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* How It Works */}
      <Section className="bg-muted/30">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our monthly collection model makes recycling simple and hassle-free.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: 1, title: "Register", description: "Sign up your school or business" },
              { step: 2, title: "Collect", description: "Gather recyclables throughout the month" },
              { step: 3, title: "Schedule", description: "Request a monthly pickup" },
              { step: 4, title: "Earn", description: "Receive points and certificates" },
            ].map((item, index) => (
              <div key={item.step} className="relative">
                <div className="text-center">
                  <div className="w-16 h-16 rounded-full gradient-primary flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                    {item.step}
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
                {index < 3 && (
                  <ArrowRight className="hidden md:block absolute top-8 -right-3 w-6 h-6 text-muted-foreground/40" />
                )}
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* Services Grid */}
      <Section>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Services
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Choose how you want to participate in our recycling initiative.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {services.map((service, index) => (
            <Card
              key={service.title}
              className="card-hover border-0 shadow-soft group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center shrink-0 group-hover:bg-green-200 transition-colors">
                    <service.icon className="w-6 h-6 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground mb-2">{service.title}</h3>
                    <p className="text-sm text-muted-foreground mb-4">{service.description}</p>
                    <Link href={service.href}>
                      <Button variant="outline" size="sm" className="group/btn bg-transparent">
                        {service.cta}
                        <ArrowRight className="w-4 h-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Impact Stats */}
      <Section className="gradient-primary text-white">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Impact</h2>
          <p className="text-white/80 max-w-2xl mx-auto">
            Together, we are making a difference for our communities and our planet.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          {[
            { value: 2500, suffix: "kg", label: "Waste Recycled" },
            { value: 15, suffix: "+", label: "Partner Schools" },
            { value: 8, suffix: "+", label: "Business Partners" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-4xl md:text-5xl font-bold mb-2">
                <AnimatedCounter end={stat.value} suffix={stat.suffix} />
              </div>
              <p className="text-white/80">{stat.label}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/recycling/impact">
            <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-white/90">
              View Full Impact Report
              <BarChart3 className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </Section>

      {/* CTA Section */}
      <Section>
        <Card className="border-0 shadow-soft-lg overflow-hidden">
          <CardContent className="p-0">
            <div className="grid md:grid-cols-2">
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4 text-balance">
                  Ready to Make a Difference?
                </h2>
                <p className="text-muted-foreground mb-6">
                  Join our growing network of schools and businesses committed to sustainable
                  recycling. Every contribution helps support education in our community.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/recycling/register">
                    <Button size="lg" className="gradient-primary w-full sm:w-auto">
                      Register Now
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link href="/contact">
                    <Button variant="outline" size="lg" className="w-full sm:w-auto bg-transparent">
                      Contact Us
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative h-64 md:h-auto bg-gradient-to-br from-green-100 to-emerald-100 flex items-center justify-center">
                <Recycle className="w-32 h-32 text-green-500/30" />
              </div>
            </div>
          </CardContent>
        </Card>
      </Section>
    </>
  );
}
