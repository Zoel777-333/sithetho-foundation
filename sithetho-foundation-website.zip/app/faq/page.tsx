"use client";

import { useState } from "react";
import Link from "next/link";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  GraduationCap,
  Wallet,
  Recycle,
  ChevronDown,
  ChevronUp,
  MessageCircle,
  ArrowRight,
  HelpCircle,
} from "lucide-react";
import { faqs } from "@/data/site";

type FAQCategory = "clc" | "nsfas" | "recycling";

const categories = [
  {
    id: "clc" as FAQCategory,
    name: "Community Learning Center",
    icon: GraduationCap,
    description: "Questions about education support and applications",
  },
  {
    id: "nsfas" as FAQCategory,
    name: "NSFAS",
    icon: Wallet,
    description: "Questions about funding and financial aid",
  },
  {
    id: "recycling" as FAQCategory,
    name: "Recycling",
    icon: Recycle,
    description: "Questions about our recycling program",
  },
];

function FAQItem({ question, answer }: { question: string; answer: string }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Card className="border-0 shadow-soft card-hover">
      <CardContent className="p-0">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-6 flex items-start justify-between gap-4 text-left"
          aria-expanded={isOpen}
        >
          <span className="font-medium text-foreground pr-4">{question}</span>
          <div className="shrink-0 mt-1">
            {isOpen ? (
              <ChevronUp className="w-5 h-5 text-muted-foreground" />
            ) : (
              <ChevronDown className="w-5 h-5 text-muted-foreground" />
            )}
          </div>
        </button>
        {isOpen && (
          <div className="px-6 pb-6 pt-0">
            <div className="border-t border-border/50 pt-4">
              <p className="text-muted-foreground leading-relaxed">{answer}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState<FAQCategory>("clc");

  const activeFaqs = faqs[activeCategory];
  const activeCategoryInfo = categories.find((c) => c.id === activeCategory);

  return (
    <>
      <PageHeader
        title="Frequently Asked Questions"
        subtitle="Find answers to common questions about our education support and recycling programs."
        logoSrc="/assets/nd.png"
        logoAlt="Sithetho Foundation Logo"
      />

      {/* Category Tabs */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`flex items-center gap-3 px-6 py-4 rounded-2xl transition-all ${
                  activeCategory === category.id
                    ? "gradient-primary text-white shadow-lg"
                    : "bg-card shadow-soft hover:shadow-md text-foreground"
                }`}
              >
                <category.icon className="w-5 h-5" />
                <span className="font-medium">{category.name}</span>
              </button>
            ))}
          </div>

          {/* Active Category Header */}
          <div className="text-center mb-8">
            <div className="flex items-center justify-center gap-3 mb-2">
              {activeCategoryInfo && (
                <activeCategoryInfo.icon className="w-6 h-6 text-primary" />
              )}
              <h2 className="text-2xl font-bold text-foreground">{activeCategoryInfo?.name}</h2>
            </div>
            <p className="text-muted-foreground">{activeCategoryInfo?.description}</p>
          </div>

          {/* FAQ List */}
          <div className="space-y-4">
            {activeFaqs.map((faq, index) => (
              <FAQItem key={index} question={faq.question} answer={faq.answer} />
            ))}
          </div>
        </div>
      </Section>

      {/* Related Links */}
      <Section className="bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-bold text-foreground text-center mb-8">
            Helpful Resources
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Link href="/clc">
              <Card className="border-0 shadow-soft card-hover h-full">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center mx-auto mb-4">
                    <GraduationCap className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">Education Services</h3>
                  <p className="text-sm text-muted-foreground">
                    Explore our free education support programs
                  </p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/clc/nsfas">
              <Card className="border-0 shadow-soft card-hover h-full">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-xl bg-green-500 flex items-center justify-center mx-auto mb-4">
                    <Wallet className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">NSFAS Guide</h3>
                  <p className="text-sm text-muted-foreground">
                    Complete guide to NSFAS applications
                  </p>
                </CardContent>
              </Card>
            </Link>
            <Link href="/recycling">
              <Card className="border-0 shadow-soft card-hover h-full">
                <CardContent className="p-6 text-center">
                  <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center mx-auto mb-4">
                    <Recycle className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">Recycling Program</h3>
                  <p className="text-sm text-muted-foreground">
                    Learn about our recycling initiatives
                  </p>
                </CardContent>
              </Card>
            </Link>
          </div>
        </div>
      </Section>

      {/* Still Have Questions */}
      <Section>
        <div className="max-w-3xl mx-auto">
          <Card className="border-0 shadow-soft-lg overflow-hidden">
            <CardContent className="p-0">
              <div className="grid md:grid-cols-2">
                <div className="p-8 md:p-12 flex flex-col justify-center">
                  <HelpCircle className="w-12 h-12 text-primary mb-4" />
                  <h2 className="text-2xl font-bold text-foreground mb-4">
                    Still Have Questions?
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    Could not find what you are looking for? Our team is here to help. Reach out
                    through WhatsApp or our contact form.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4">
                    <a
                      href="https://wa.me/27791296823"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button className="bg-green-500 hover:bg-green-600 w-full sm:w-auto">
                        <MessageCircle className="w-5 h-5 mr-2" />
                        WhatsApp Us
                      </Button>
                    </a>
                    <Link href="/contact">
                      <Button variant="outline" className="w-full sm:w-auto bg-transparent">
                        Contact Form
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Button>
                    </Link>
                  </div>
                </div>
                <div className="relative h-48 md:h-auto gradient-primary flex items-center justify-center">
                  <MessageCircle className="w-24 h-24 text-white/20" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>
    </>
  );
}
