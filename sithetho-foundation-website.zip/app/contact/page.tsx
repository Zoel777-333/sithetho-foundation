import { Metadata } from "next";
import Link from "next/link";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { GoogleFormEmbed } from "@/components/ui/google-form-embed";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { siteConfig } from "@/data/site";
import {
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  Phone,
  ArrowRight,
  ExternalLink,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Sithetho Foundation. We are here to help with education guidance, recycling inquiries, and partnership opportunities.",
};

const contactMethods = [
  {
    icon: MessageCircle,
    title: "WhatsApp",
    description: "Chat with us directly for quick responses.",
    value: siteConfig.phone,
    action: `https://wa.me/${siteConfig.whatsapp}`,
    actionLabel: "Open WhatsApp",
    primary: true,
  },
  {
    icon: Mail,
    title: "Email",
    description: "Send us a detailed message.",
    value: siteConfig.email,
    action: `mailto:${siteConfig.email}`,
    actionLabel: "Send Email",
    primary: false,
  },
  {
    icon: MapPin,
    title: "Location",
    description: "We serve the Eastern Cape region.",
    value: siteConfig.location,
    action: null,
    actionLabel: null,
    primary: false,
  },
];

const availability = [
  { day: "Monday - Friday", hours: "12:00 - 16:00" },
  { day: "Saturday", hours: "All day" },
  { day: "Sunday", hours: "16:00 - 18:00" },
];

const topics = [
  {
    title: "Education Support",
    description: "Questions about university applications, APS, NSFAS, or career guidance.",
    link: "/clc",
  },
  {
    title: "Recycling Program",
    description: "Inquiries about registering your school or business for recycling.",
    link: "/recycling",
  },
  {
    title: "Partnership & Sponsorship",
    description: "Interested in supporting our mission through donations or partnerships.",
    link: "/sponsors",
  },
  {
    title: "General Inquiries",
    description: "Any other questions about Sithetho Foundation.",
    link: null,
  },
];

export default function ContactPage() {
  return (
    <>
      <PageHeader
        title="Contact Us"
        subtitle="We are here to help. Reach out through any of our channels below."
        logoSrc="/assets/nd.png"
        logoAlt="Sithetho Foundation Logo"
      />

      {/* Contact Methods */}
      <Section>
        <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
          {contactMethods.map((method, index) => (
            <Card
              key={method.title}
              className={`border-0 shadow-soft-lg card-hover ${
                method.primary ? "ring-2 ring-green-400 ring-offset-2" : ""
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6 text-center">
                <div
                  className={`w-14 h-14 rounded-2xl ${
                    method.primary ? "bg-green-500" : "gradient-primary"
                  } flex items-center justify-center mx-auto mb-4`}
                >
                  <method.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-1">{method.title}</h3>
                <p className="text-sm text-muted-foreground mb-3">{method.description}</p>
                <p className="font-medium text-foreground mb-4">{method.value}</p>
                {method.action && (
                  <a href={method.action} target="_blank" rel="noopener noreferrer">
                    <Button
                      variant={method.primary ? "default" : "outline"}
                      size="sm"
                      className={method.primary ? "bg-green-500 hover:bg-green-600" : ""}
                    >
                      {method.actionLabel}
                      <ExternalLink className="w-4 h-4 ml-2" />
                    </Button>
                  </a>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Availability */}
      <Section className="bg-muted/30">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-foreground">Availability Hours</h2>
              </div>
              <p className="text-muted-foreground mb-6">
                Our team is available to assist you during the following hours. For urgent matters,
                WhatsApp is the fastest way to reach us.
              </p>
              <Card className="border-0 shadow-soft">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    {availability.map((slot) => (
                      <div
                        key={slot.day}
                        className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
                      >
                        <span className="font-medium text-foreground">{slot.day}</span>
                        <span className="text-muted-foreground">{slot.hours}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <h2 className="text-2xl font-bold text-foreground mb-6">What Can We Help With?</h2>
              <div className="space-y-4">
                {topics.map((topic) => (
                  <Card key={topic.title} className="border-0 shadow-soft card-hover">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-semibold text-foreground mb-1">{topic.title}</h3>
                          <p className="text-sm text-muted-foreground">{topic.description}</p>
                        </div>
                        {topic.link && (
                          <Link href={topic.link}>
                            <Button variant="ghost" size="sm">
                              <ArrowRight className="w-4 h-4" />
                            </Button>
                          </Link>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        </div>
      </Section>

      {/* Contact Form */}
      <Section>
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Send Us a Message</h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              Fill out the form below and we will get back to you as soon as possible.
            </p>
          </div>

          <Card className="border-0 shadow-soft-lg">
            <CardContent className="p-6 md:p-8">
              <GoogleFormEmbed
                formUrl="https://docs.google.com/forms/d/e/YOUR_CONTACT_FORM_ID/viewform"
                title="Contact Form"
                height={700}
              />
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Quick WhatsApp CTA */}
      <Section className="bg-green-500 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <MessageCircle className="w-16 h-16 mx-auto mb-6 text-white/80" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Prefer to Chat?</h2>
          <p className="text-white/80 mb-8 max-w-xl mx-auto">
            WhatsApp is the quickest way to reach us. Send us a message and we will respond as
            soon as we are available.
          </p>
          <a
            href={`https://wa.me/${siteConfig.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" className="bg-white text-green-600 hover:bg-white/90">
              <MessageCircle className="w-5 h-5 mr-2" />
              Chat on WhatsApp
            </Button>
          </a>
        </div>
      </Section>
    </>
  );
}
