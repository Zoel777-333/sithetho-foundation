import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { siteConfig } from "@/data/site";
import { Heart, Eye, Star, Users, Shield, Leaf } from "lucide-react";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Learn about Sithetho Foundation's mission to empower learners and communities through free education guidance and sustainable recycling solutions.",
};

const valueIcons = {
  Empowerment: Heart,
  Access: Users,
  Integrity: Shield,
  Excellence: Star,
  Community: Users,
  Sustainability: Leaf,
};

export default function AboutPage() {
  return (
    <>
      <PageHeader
        title="About Sithetho Foundation"
        description="Empowering learners and communities since 2024"
        logo="/assets/nd.png"
      />

      {/* Story Section */}
      <Section variant="default">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-sm font-medium text-primary tracking-widest uppercase mb-4">
              Our Story
            </p>
            <h2 className="text-3xl font-bold text-foreground sm:text-4xl text-balance">
              Born from a Vision to Transform Communities
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Sithetho Foundation, also known as New Dawn Foundation, was
                established in 2024 in Mdantsane, East London, with a clear
                purpose: to bridge the gap between learners and their educational
                dreams.
              </p>
              <p>
                Founded by Mr. Thandi Sithetho, an educator with a deep
                understanding of the challenges faced by underprivileged
                communities, the foundation emerged from the realization that
                many capable learners miss out on opportunities simply because
                they lack guidance and support.
              </p>
              <p>
                What started as informal assistance to a few learners has grown
                into a structured initiative offering comprehensive education
                guidance and community recycling programs.
              </p>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-3xl bg-gradient-to-br from-primary/10 to-secondary/10 p-8 flex items-center justify-center">
              <div className="text-center">
                <p className="text-6xl lg:text-8xl font-bold gradient-text">
                  {siteConfig.founded}
                </p>
                <p className="mt-4 text-lg text-muted-foreground">Year Founded</p>
              </div>
            </div>
            <div className="absolute -bottom-4 -right-4 h-24 w-24 rounded-2xl gradient-primary flex items-center justify-center text-primary-foreground shadow-lg">
              <Heart className="h-10 w-10" />
            </div>
          </div>
        </div>
      </Section>

      {/* Founder Section */}
      <Section variant="muted">
        <div className="rounded-3xl bg-card p-8 lg:p-12 shadow-soft border border-border/50">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-1">
              <div className="relative aspect-square max-w-[280px] mx-auto rounded-3xl overflow-hidden bg-gradient-to-br from-primary/20 to-secondary/20 flex items-center justify-center">
                <div className="text-center p-6">
                  <div className="w-32 h-32 mx-auto rounded-full gradient-primary flex items-center justify-center text-primary-foreground text-4xl font-bold">
                    TS
                  </div>
                  <p className="mt-4 text-sm text-muted-foreground">Founder & Executive Director</p>
                </div>
              </div>
            </div>
            <div className="lg:col-span-2">
              <p className="text-sm font-medium text-primary tracking-widest uppercase mb-4">
                Meet Our Founder
              </p>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">
                {siteConfig.founder.name}
              </h2>
              <p className="text-primary mt-1">{siteConfig.founder.title}</p>
              <p className="mt-6 text-muted-foreground leading-relaxed">
                {siteConfig.founder.bio}
              </p>
              <blockquote className="mt-6 pl-4 border-l-4 border-primary italic text-muted-foreground">
                "Every learner has potential. Our job is to help them discover it and reach it."
              </blockquote>
            </div>
          </div>
        </div>
      </Section>

      {/* Mission & Vision */}
      <Section variant="default">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Mission */}
          <div className="rounded-3xl bg-card p-8 lg:p-10 shadow-soft border border-border/50 card-hover">
            <div className="mb-6 inline-flex items-center justify-center rounded-2xl gradient-primary p-4 text-primary-foreground">
              <Heart className="h-8 w-8" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
            <p className="text-muted-foreground leading-relaxed text-lg">
              {siteConfig.mission}
            </p>
          </div>

          {/* Vision */}
          <div className="rounded-3xl bg-card p-8 lg:p-10 shadow-soft border border-border/50 card-hover">
            <div className="mb-6 inline-flex items-center justify-center rounded-2xl gradient-primary p-4 text-primary-foreground">
              <Eye className="h-8 w-8" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
            <p className="text-muted-foreground leading-relaxed text-lg">
              {siteConfig.vision}
            </p>
          </div>
        </div>
      </Section>

      {/* Core Values */}
      <Section variant="muted">
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary tracking-widest uppercase mb-4">
            What We Stand For
          </p>
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            Our Core Values
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {siteConfig.values.map((value) => {
            const Icon = valueIcons[value.name as keyof typeof valueIcons] || Star;
            return (
              <div
                key={value.name}
                className="rounded-2xl bg-card p-6 shadow-soft border border-border/50 card-hover"
              >
                <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground">
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {value.name}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {value.description}
                </p>
              </div>
            );
          })}
        </div>
      </Section>

      {/* Scripture/Inspiration */}
      <Section variant="gradient">
        <div className="text-center max-w-3xl mx-auto">
          <blockquote className="text-2xl lg:text-3xl font-medium text-foreground italic leading-relaxed">
            "For I know the plans I have for you, declares the Lord, plans to
            prosper you and not to harm you, plans to give you hope and a
            future."
          </blockquote>
          <p className="mt-6 text-muted-foreground">— Jeremiah 29:11</p>
        </div>
      </Section>

      {/* CTA */}
      <Section variant="default">
        <div className="relative overflow-hidden rounded-3xl gradient-primary p-8 lg:p-12 text-center">
          <div className="relative z-10">
            <h2 className="text-2xl lg:text-3xl font-bold text-primary-foreground">
              Join Our Mission
            </h2>
            <p className="mt-4 text-primary-foreground/90 max-w-xl mx-auto">
              Whether as a learner seeking guidance, a school partner, or a
              sponsor, there's a place for you in our community.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-white text-primary hover:bg-white/90 rounded-full px-8"
              >
                <Link href="/clc/book-assistance">Get Free Assistance</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/10 rounded-full px-8 bg-transparent"
              >
                <Link href="/sponsors">Become a Sponsor</Link>
              </Button>
            </div>
          </div>
          <div className="absolute -left-20 -top-20 h-60 w-60 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -right-20 -bottom-20 h-60 w-60 rounded-full bg-white/10 blur-2xl" />
        </div>
      </Section>
    </>
  );
}
