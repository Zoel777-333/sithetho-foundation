import { Metadata } from "next";
import Link from "next/link";
import { Section } from "@/components/ui/section";
import { PageHeader } from "@/components/ui/page-header";
import { GoogleFormEmbed } from "@/components/ui/google-form-embed";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Heart,
  Users,
  GraduationCap,
  Recycle,
  Building2,
  Calendar,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  Clock,
  HandHeart,
} from "lucide-react";

export const metadata: Metadata = {
  title: "Sponsors & Partners",
  description:
    "Support Sithetho Foundation through donations and partnerships. Help us provide free education guidance to learners.",
};

const whySupport = [
  {
    icon: GraduationCap,
    title: "Education Access",
    description: "Your support helps learners access university applications and career guidance completely free.",
  },
  {
    icon: Recycle,
    title: "Environmental Impact",
    description: "Fund recycling initiatives that keep communities clean while supporting education.",
  },
  {
    icon: Users,
    title: "Community Development",
    description: "Invest in the future of Mdantsane and East London through sustainable programs.",
  },
  {
    icon: Heart,
    title: "Direct Impact",
    description: "100% of donations go directly to programs. We operate with minimal overhead.",
  },
];

const donationTypes = [
  {
    type: "Once-off",
    icon: Sparkles,
    description: "Make a single contribution to support our programs.",
    benefits: [
      "Immediate impact on learners",
      "Tax-deductible donation",
      "Recognition certificate",
      "Impact report",
    ],
  },
  {
    type: "Monthly",
    icon: Calendar,
    description: "Become a sustaining partner with regular monthly support.",
    benefits: [
      "Sustained program funding",
      "Monthly impact updates",
      "Partner recognition",
      "Annual impact report",
      "Exclusive event invitations",
    ],
    recommended: true,
  },
];

const partnershipTiers = [
  {
    name: "Community Partner",
    amount: "R500 - R2,000",
    benefits: ["Website recognition", "Certificate of partnership", "Quarterly updates"],
  },
  {
    name: "Education Champion",
    amount: "R2,001 - R10,000",
    benefits: [
      "All Community Partner benefits",
      "Social media recognition",
      "Annual impact report",
      "Partner event access",
    ],
  },
  {
    name: "Foundation Patron",
    amount: "R10,001+",
    benefits: [
      "All Education Champion benefits",
      "Named program sponsorship",
      "Board meeting invitations",
      "Custom impact metrics",
      "Priority partnership opportunities",
    ],
  },
];

export default function SponsorsPage() {
  return (
    <>
      <PageHeader
        title="Support Our Mission"
        subtitle="Partner with us to provide free education guidance and build cleaner communities."
        logoSrc="/assets/nd.png"
        logoAlt="Sithetho Foundation Logo"
      />

      {/* Why Support Us */}
      <Section>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Support Sithetho Foundation?
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Your contribution directly impacts learners and communities in the Eastern Cape.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {whySupport.map((item, index) => (
            <Card
              key={item.title}
              className="border-0 shadow-soft card-hover text-center"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-6">
                <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Donation Types */}
      <Section className="bg-muted/30">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Ways to Give</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Choose how you would like to support our mission.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {donationTypes.map((donation) => (
            <Card
              key={donation.type}
              className={`border-0 shadow-soft-lg card-hover relative overflow-hidden ${
                donation.recommended ? "ring-2 ring-primary ring-offset-2" : ""
              }`}
            >
              {donation.recommended && (
                <div className="absolute top-4 right-4 bg-primary text-white text-xs px-3 py-1 rounded-full font-medium">
                  Recommended
                </div>
              )}
              <CardContent className="p-8">
                <div className="w-14 h-14 rounded-2xl gradient-primary flex items-center justify-center mb-6">
                  <donation.icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-2">{donation.type} Donation</h3>
                <p className="text-muted-foreground mb-6">{donation.description}</p>
                <ul className="space-y-2 mb-6">
                  {donation.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Partnership Tiers */}
      <Section>
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Partnership Tiers</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Join our network of partners committed to education and sustainability.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {partnershipTiers.map((tier, index) => (
            <Card
              key={tier.name}
              className={`border-0 shadow-soft card-hover ${
                index === 2 ? "ring-2 ring-primary ring-offset-2" : ""
              }`}
            >
              <CardContent className="p-6">
                <h3 className="text-lg font-bold text-foreground mb-1">{tier.name}</h3>
                <p className="text-2xl font-bold gradient-text mb-4">{tier.amount}</p>
                <ul className="space-y-2">
                  {tier.benefits.map((benefit) => (
                    <li key={benefit} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0 mt-0.5" />
                      {benefit}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </Section>

      {/* Government Partnerships */}
      <Section className="bg-gradient-to-br from-blue-50/50 to-indigo-50/50">
        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-soft-lg">
            <CardContent className="p-8 md:p-12 text-center">
              <div className="w-16 h-16 rounded-2xl bg-blue-100 flex items-center justify-center mx-auto mb-6">
                <Building2 className="w-8 h-8 text-blue-600" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                Government Partnerships
              </h2>
              <p className="text-muted-foreground mb-6 max-w-xl mx-auto">
                We are actively pursuing partnerships with government departments to expand our
                reach and impact. Official government partnership programs are coming soon.
              </p>
              <div className="flex items-center justify-center gap-2 text-muted-foreground">
                <Clock className="w-5 h-5" />
                <span>Coming Later in 2025</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* Partnership Form */}
      <Section>
        <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
              Become a Partner
            </h2>
            <p className="text-muted-foreground mb-6">
              Fill out the form to express your interest in partnering with Sithetho Foundation.
              Our team will reach out to discuss partnership opportunities that align with your goals.
            </p>

            <div className="space-y-4 mb-8">
              {[
                "Support free education for learners",
                "Make a tangible community impact",
                "Align with sustainable practices",
                "Receive recognition and reporting",
              ].map((item) => (
                <div key={item} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full gradient-primary flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-4 h-4 text-white" />
                  </div>
                  <span className="text-muted-foreground">{item}</span>
                </div>
              ))}
            </div>

            <Card className="border-0 shadow-soft bg-gradient-to-br from-primary/5 to-secondary/5">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center shrink-0">
                    <HandHeart className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">Every Contribution Matters</h3>
                    <p className="text-sm text-muted-foreground">
                      Whether you contribute R100 or R100,000, your support helps a learner access
                      their future. Thank you for considering partnership with us.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-0 shadow-soft-lg">
            <CardContent className="p-6 md:p-8">
              <h3 className="text-xl font-semibold text-foreground mb-6">Partnership Interest Form</h3>
              <GoogleFormEmbed
                formUrl="https://docs.google.com/forms/d/e/YOUR_PARTNERSHIP_FORM_ID/viewform"
                title="Partnership Interest Form"
                height={600}
              />
            </CardContent>
          </Card>
        </div>
      </Section>

      {/* CTA */}
      <Section className="gradient-primary text-white">
        <div className="max-w-3xl mx-auto text-center">
          <Heart className="w-16 h-16 mx-auto mb-6 text-white/80" />
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Make a Difference?</h2>
          <p className="text-white/80 mb-8 max-w-xl mx-auto">
            Join the growing community of partners who believe in education access and sustainable
            communities.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact">
              <Button size="lg" className="bg-white text-primary hover:bg-white/90 w-full sm:w-auto">
                Contact Us Today
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link href="/about">
              <Button
                size="lg"
                variant="outline"
                className="border-white/30 text-white hover:bg-white/10 w-full sm:w-auto bg-transparent"
              >
                Learn Our Story
              </Button>
            </Link>
          </div>
        </div>
      </Section>
    </>
  );
}
