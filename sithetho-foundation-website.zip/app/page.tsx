import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Section } from "@/components/ui/section";
import { FeatureCard } from "@/components/ui/feature-card";
import { AnimatedCounter } from "@/components/ui/animated-counter";
import { impactStats, clcServices } from "@/data/site";
import { ArrowRight, Users, Building, Recycle, Heart } from "lucide-react";

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 gradient-primary-subtle" />
        <div className="absolute -left-40 -top-40 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -right-40 -bottom-40 h-96 w-96 rounded-full bg-secondary/10 blur-3xl" />

        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
          <div className="text-center">
            {/* Logo */}
            <div className="flex justify-center mb-8">
              <div className="relative h-24 w-24 lg:h-32 lg:w-32 animate-float">
                <Image
                  src="/assets/nd.png"
                  alt="Sithetho Foundation Logo"
                  fill
                  className="object-contain"
                  priority
                />
              </div>
            </div>

            {/* Tagline */}
            <p className="text-sm font-medium text-primary tracking-widest uppercase mb-4 animate-fade-in">
              Phuhlisa • Empower
            </p>

            {/* Headline */}
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl xl:text-7xl animate-fade-in-up text-balance">
              Education Access.{" "}
              <span className="gradient-text">Community Impact.</span>
            </h1>

            {/* Subheadline */}
            <p className="mt-6 max-w-2xl mx-auto text-lg text-muted-foreground leading-relaxed animate-fade-in-up text-pretty" style={{ animationDelay: "0.2s" }}>
              Free guidance for applications, APS, NSFAS and careers — plus
              recycling initiatives that keep communities clean.
            </p>

            {/* CTAs */}
            <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
              <Button
                asChild
                size="lg"
                className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8 text-base"
              >
                <Link href="/clc/universities">
                  Apply Now
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="rounded-full px-8 text-base border-2 hover:bg-accent bg-transparent"
              >
                <Link href="/clc/book-assistance">Book Free Assistance</Link>
              </Button>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="h-10 w-6 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-1">
            <div className="h-2 w-1 rounded-full bg-muted-foreground/50" />
          </div>
        </div>
      </section>

      {/* Main Divisions */}
      <Section variant="default">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl text-balance">
            Our Two Pillars of Impact
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Education and environmental sustainability working together for stronger communities.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <FeatureCard
            title="Community Learning Center"
            description="Free education guidance, university and college application support, APS calculation, career counseling, and NSFAS assistance for learners across the Eastern Cape."
            href="/clc"
            icon="GraduationCap"
            variant="large"
          />
          <FeatureCard
            title="Recycling Division"
            description="Monthly collection of recyclable materials from schools and businesses, rewarding environmental responsibility while keeping our communities clean."
            href="/recycling"
            icon="Recycle"
            variant="large"
          />
        </div>
      </Section>

      {/* Impact Stats */}
      <Section variant="muted">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl">
            Our Impact So Far
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Numbers that represent real lives changed.
          </p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          <div className="rounded-2xl bg-card p-6 lg:p-8 shadow-soft text-center border border-border/50">
            <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground">
              <Users className="h-6 w-6" />
            </div>
            <p className="text-3xl lg:text-4xl font-bold text-foreground">
              <AnimatedCounter end={impactStats.learnersAssisted} suffix="+" />
            </p>
            <p className="mt-2 text-sm text-muted-foreground">Learners Assisted</p>
          </div>

          <div className="rounded-2xl bg-card p-6 lg:p-8 shadow-soft text-center border border-border/50">
            <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground">
              <Building className="h-6 w-6" />
            </div>
            <p className="text-3xl lg:text-4xl font-bold text-foreground">
              <AnimatedCounter end={impactStats.schoolsPartnered + impactStats.businessesPartnered} suffix="+" />
            </p>
            <p className="mt-2 text-sm text-muted-foreground">Partners</p>
          </div>

          <div className="rounded-2xl bg-card p-6 lg:p-8 shadow-soft text-center border border-border/50">
            <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground">
              <Recycle className="h-6 w-6" />
            </div>
            <p className="text-3xl lg:text-4xl font-bold text-foreground">
              <AnimatedCounter end={impactStats.wasteRecycledKg} suffix=" kg" />
            </p>
            <p className="mt-2 text-sm text-muted-foreground">Waste Recycled</p>
          </div>

          <div className="rounded-2xl bg-card p-6 lg:p-8 shadow-soft text-center border border-border/50">
            <div className="mb-4 inline-flex items-center justify-center rounded-xl gradient-primary p-3 text-primary-foreground">
              <Heart className="h-6 w-6" />
            </div>
            <p className="text-3xl lg:text-4xl font-bold text-foreground">
              <AnimatedCounter end={impactStats.communitiesReached} suffix="+" />
            </p>
            <p className="mt-2 text-sm text-muted-foreground">Communities Reached</p>
          </div>
        </div>
      </Section>

      {/* CLC Services Grid */}
      <Section variant="default">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-foreground sm:text-4xl text-balance">
            All Services. Completely Free.
          </h2>
          <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
            Every learner deserves access to education guidance, regardless of their circumstances.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {clcServices.map((service) => (
            <FeatureCard
              key={service.id}
              title={service.title}
              description={service.description}
              href={service.href}
              icon={service.icon}
            />
          ))}
        </div>
      </Section>

      {/* Sponsors Teaser */}
      <Section variant="gradient">
        <div className="rounded-3xl bg-card p-8 lg:p-12 shadow-soft-lg border border-border/50">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="text-center lg:text-left">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">
                Partner With Us
              </h2>
              <p className="mt-3 text-muted-foreground max-w-xl">
                Join our mission to empower communities through education and sustainability. 
                Your support creates lasting change.
              </p>
            </div>
            <Button
              asChild
              size="lg"
              className="gradient-primary text-primary-foreground hover:opacity-90 transition-opacity rounded-full px-8 whitespace-nowrap"
            >
              <Link href="/sponsors">Become a Sponsor</Link>
            </Button>
          </div>
        </div>
      </Section>

      {/* CTA Banner */}
      <Section variant="muted">
        <div className="relative overflow-hidden rounded-3xl gradient-primary p-8 lg:p-16 text-center">
          <div className="relative z-10">
            <h2 className="text-3xl lg:text-4xl font-bold text-primary-foreground text-balance">
              Ready to Start Your Journey?
            </h2>
            <p className="mt-4 text-lg text-primary-foreground/90 max-w-xl mx-auto">
              Book a free one-on-one session with our education advisors today.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                asChild
                size="lg"
                className="bg-white text-primary hover:bg-white/90 rounded-full px-8"
              >
                <Link href="/clc/book-assistance">Book Free Session</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-2 border-white text-white hover:bg-white/10 rounded-full px-8 bg-transparent"
              >
                <Link href="/clc/aps-calculator">Calculate Your APS</Link>
              </Button>
            </div>
          </div>
          {/* Decorative circles */}
          <div className="absolute -left-20 -top-20 h-60 w-60 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -right-20 -bottom-20 h-60 w-60 rounded-full bg-white/10 blur-2xl" />
        </div>
      </Section>
    </>
  );
}
