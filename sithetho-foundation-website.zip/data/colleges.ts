export interface College {
  id: string;
  slug: string;
  name: string;
  shortName: string;
  type: "public-tvet" | "private";
  province: string;
  city: string;
  description: string;
  website: string;
  applicationFee: string;
  applicationDeadline: string;
  minAPS?: number;
  requiredDocuments: string[];
  popularCourses: string[];
  accommodationLink?: string;
  nsfasAccredited: boolean;
  contactEmail?: string;
  contactPhone?: string;
}

export const colleges: College[] = [
  // Public TVET Colleges
  {
    id: "buffalo-city-tvet",
    slug: "buffalo-city-tvet-college",
    name: "Buffalo City TVET College",
    shortName: "BCTVET",
    type: "public-tvet",
    province: "Eastern Cape",
    city: "East London",
    description: "Buffalo City TVET College is a leading technical and vocational college in the Eastern Cape, serving the Buffalo City Metropolitan area with quality skills training.",
    website: "https://www.bccollege.co.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results (depending on programme)",
      "Proof of residence"
    ],
    popularCourses: ["Engineering Studies", "Business Studies", "IT Studies", "Tourism", "Hospitality"],
    nsfasAccredited: true,
    contactEmail: "info@bccollege.co.za",
    contactPhone: "043 704 9218"
  },
  {
    id: "king-hintsa-tvet",
    slug: "king-hintsa-tvet-college",
    name: "King Hintsa TVET College",
    shortName: "KHTVET",
    type: "public-tvet",
    province: "Eastern Cape",
    city: "Butterworth",
    description: "King Hintsa TVET College provides vocational education and training to communities in the OR Tambo and Amathole districts of the Eastern Cape.",
    website: "https://www.kinghintsacollege.edu.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Engineering Studies", "Business Studies", "Hospitality", "Agriculture"],
    nsfasAccredited: true,
    contactEmail: "info@kinghintsacollege.edu.za",
    contactPhone: "047 401 6400"
  },
  {
    id: "lovedale-tvet",
    slug: "lovedale-tvet-college",
    name: "Lovedale TVET College",
    shortName: "LTVET",
    type: "public-tvet",
    province: "Eastern Cape",
    city: "Alice",
    description: "Lovedale TVET College has a rich history dating back to 1841 and continues to provide quality vocational education to the Eastern Cape region.",
    website: "https://www.lovedalecollege.co.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Business Studies", "Engineering Studies", "Agriculture", "Hospitality"],
    nsfasAccredited: true,
    contactEmail: "info@lovedalecollege.co.za",
    contactPhone: "040 653 0029"
  },
  {
    id: "eastcape-midlands-tvet",
    slug: "eastcape-midlands-tvet-college",
    name: "Eastcape Midlands TVET College",
    shortName: "EMTVET",
    type: "public-tvet",
    province: "Eastern Cape",
    city: "Uitenhage",
    description: "Eastcape Midlands TVET College serves the Sarah Baartman district with quality technical and vocational education programmes.",
    website: "https://www.emcol.co.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Engineering Studies", "Business Studies", "IT", "Hospitality"],
    nsfasAccredited: true,
    contactEmail: "info@emcol.co.za",
    contactPhone: "041 995 2000"
  },
  {
    id: "ekurhuleni-west-tvet",
    slug: "ekurhuleni-west-tvet-college",
    name: "Ekurhuleni West TVET College",
    shortName: "EWTVET",
    type: "public-tvet",
    province: "Gauteng",
    city: "Germiston",
    description: "Ekurhuleni West TVET College is one of the largest TVET colleges in Gauteng, offering a wide range of vocational programmes.",
    website: "https://www.ewc.edu.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Engineering Studies", "Business Studies", "IT", "Marketing"],
    nsfasAccredited: true,
    contactEmail: "info@ewc.edu.za",
    contactPhone: "011 323 1600"
  },
  {
    id: "central-jhb-tvet",
    slug: "central-johannesburg-tvet-college",
    name: "Central Johannesburg TVET College",
    shortName: "CJTVET",
    type: "public-tvet",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Central Johannesburg TVET College serves the heart of Johannesburg with practical skills training for the job market.",
    website: "https://www.cjc.edu.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Business Studies", "Engineering Studies", "Hospitality", "Art and Design"],
    nsfasAccredited: true,
    contactEmail: "info@cjc.edu.za",
    contactPhone: "011 484 2738"
  },
  {
    id: "coastal-kzn-tvet",
    slug: "coastal-kzn-tvet-college",
    name: "Coastal KZN TVET College",
    shortName: "CKTVET",
    type: "public-tvet",
    province: "KwaZulu-Natal",
    city: "Durban",
    description: "Coastal KZN TVET College is the largest public TVET college in KwaZulu-Natal, serving the eThekwini metropolitan area.",
    website: "https://www.coastalkzn.co.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Engineering Studies", "Business Studies", "Tourism", "IT"],
    nsfasAccredited: true,
    contactEmail: "info@coastalkzn.co.za",
    contactPhone: "031 905 7000"
  },
  {
    id: "false-bay-tvet",
    slug: "false-bay-tvet-college",
    name: "False Bay TVET College",
    shortName: "FBTVET",
    type: "public-tvet",
    province: "Western Cape",
    city: "Cape Town",
    description: "False Bay TVET College serves the southern suburbs and False Bay coast of Cape Town with quality vocational education.",
    website: "https://www.falsebaycollege.co.za",
    applicationFee: "Free",
    applicationDeadline: "30 November",
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 9 or Grade 12 results",
      "Proof of residence"
    ],
    popularCourses: ["Business Studies", "Engineering Studies", "IT", "Hospitality"],
    nsfasAccredited: true,
    contactEmail: "info@falsebaycollege.co.za",
    contactPhone: "021 787 0800"
  },
  // Private Colleges
  {
    id: "boston-city",
    slug: "boston-city-campus",
    name: "Boston City Campus & Business College",
    shortName: "Boston",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Boston City Campus offers a wide range of accredited programmes from certificates to degrees in business, IT, and creative fields.",
    website: "https://www.boston.co.za",
    applicationFee: "R500",
    applicationDeadline: "Rolling admissions",
    requiredDocuments: [
      "Certified copy of ID",
      "Matric certificate",
      "Proof of payment"
    ],
    popularCourses: ["Business Management", "IT", "Graphic Design", "Marketing"],
    nsfasAccredited: false,
    contactEmail: "info@boston.co.za",
    contactPhone: "011 551 2000"
  },
  {
    id: "damelin",
    slug: "damelin-college",
    name: "Damelin College",
    shortName: "Damelin",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Damelin is a well-established private college offering career-focused programmes in business, IT, engineering, and creative fields.",
    website: "https://www.damelin.co.za",
    applicationFee: "R500",
    applicationDeadline: "Rolling admissions",
    requiredDocuments: [
      "Certified copy of ID",
      "Matric certificate or equivalent",
      "Proof of payment"
    ],
    popularCourses: ["Business Management", "IT", "Engineering", "Accounting"],
    nsfasAccredited: false,
    contactEmail: "info@damelin.co.za",
    contactPhone: "086 123 2642"
  },
  {
    id: "varsity-college",
    slug: "varsity-college",
    name: "Varsity College",
    shortName: "VC",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Varsity College is part of The Independent Institute of Education and offers accredited degrees and diplomas across multiple campuses in South Africa.",
    website: "https://www.varsitycollege.co.za",
    applicationFee: "R500",
    applicationDeadline: "Rolling admissions",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 or Grade 12 results",
      "Proof of payment"
    ],
    popularCourses: ["BCom", "LLB", "BA", "IT", "Media Studies"],
    nsfasAccredited: false,
    contactEmail: "info@varsitycollege.co.za",
    contactPhone: "086 122 2444"
  },
  {
    id: "rosebank-college",
    slug: "rosebank-college",
    name: "Rosebank College",
    shortName: "RC",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Rosebank College offers affordable, quality education with a focus on workplace readiness and practical skills.",
    website: "https://www.rosebankcollege.co.za",
    applicationFee: "R200",
    applicationDeadline: "Rolling admissions",
    requiredDocuments: [
      "Certified copy of ID",
      "Matric certificate",
      "Proof of payment"
    ],
    popularCourses: ["Business Management", "IT", "Policing", "Human Resources"],
    nsfasAccredited: false,
    contactEmail: "info@rosebankcollege.co.za",
    contactPhone: "086 122 3423"
  }
];

export function getCollegeBySlug(slug: string): College | undefined {
  return colleges.find(c => c.slug === slug);
}

export function filterColleges(
  province?: string,
  type?: "public-tvet" | "private",
  search?: string
): College[] {
  return colleges.filter(c => {
    const matchProvince = !province || c.province === province;
    const matchType = !type || c.type === type;
    const matchSearch = !search || 
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.shortName.toLowerCase().includes(search.toLowerCase());
    return matchProvince && matchType && matchSearch;
  });
}
