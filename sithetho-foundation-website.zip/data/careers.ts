export interface Career {
  id: string;
  title: string;
  cluster: "science" | "commerce" | "arts" | "technical";
  description: string;
  requiredSubjects: string[];
  recommendedSubjects?: string[];
  minAPS: number;
  demandLevel: "high" | "medium" | "low";
  salaryRange: {
    entry: string;
    mid: string;
    senior: string;
  };
  studyPaths: string[];
  skillsRequired: string[];
}

export const careers: Career[] = [
  // Science Cluster
  {
    id: "doctor",
    title: "Medical Doctor",
    cluster: "science",
    description: "Diagnose and treat illnesses, injuries, and other health conditions. Work in hospitals, clinics, or private practice.",
    requiredSubjects: ["Mathematics", "Physical Sciences", "Life Sciences"],
    recommendedSubjects: ["English"],
    minAPS: 38,
    demandLevel: "high",
    salaryRange: {
      entry: "R650,000 - R800,000",
      mid: "R900,000 - R1,500,000",
      senior: "R1,500,000 - R3,000,000+"
    },
    studyPaths: ["MBChB (6 years)", "Internship (2 years)", "Community Service (1 year)"],
    skillsRequired: ["Critical thinking", "Communication", "Empathy", "Attention to detail", "Stamina"]
  },
  {
    id: "nurse",
    title: "Professional Nurse",
    cluster: "science",
    description: "Provide patient care, administer medications, and support medical teams in hospitals and healthcare facilities.",
    requiredSubjects: ["Life Sciences", "Mathematics/Mathematical Literacy"],
    recommendedSubjects: ["Physical Sciences", "English"],
    minAPS: 24,
    demandLevel: "high",
    salaryRange: {
      entry: "R280,000 - R350,000",
      mid: "R400,000 - R550,000",
      senior: "R600,000 - R900,000"
    },
    studyPaths: ["Bachelor of Nursing (4 years)", "Diploma in Nursing (3 years)"],
    skillsRequired: ["Compassion", "Physical stamina", "Communication", "Attention to detail"]
  },
  {
    id: "engineer-civil",
    title: "Civil Engineer",
    cluster: "science",
    description: "Design, build, and maintain infrastructure projects like roads, bridges, dams, and buildings.",
    requiredSubjects: ["Mathematics", "Physical Sciences"],
    recommendedSubjects: ["English", "Technical subjects"],
    minAPS: 32,
    demandLevel: "high",
    salaryRange: {
      entry: "R400,000 - R550,000",
      mid: "R650,000 - R900,000",
      senior: "R1,000,000 - R2,000,000"
    },
    studyPaths: ["BSc Engineering (4 years)", "BTech Civil Engineering (4 years)"],
    skillsRequired: ["Problem-solving", "Mathematics", "Project management", "Technical drawing"]
  },
  {
    id: "software-developer",
    title: "Software Developer",
    cluster: "science",
    description: "Design, code, and maintain software applications, websites, and systems.",
    requiredSubjects: ["Mathematics"],
    recommendedSubjects: ["Physical Sciences", "IT", "English"],
    minAPS: 28,
    demandLevel: "high",
    salaryRange: {
      entry: "R350,000 - R500,000",
      mid: "R550,000 - R900,000",
      senior: "R950,000 - R2,000,000"
    },
    studyPaths: ["BSc Computer Science (3-4 years)", "Diploma in IT (3 years)", "Boot camps"],
    skillsRequired: ["Logical thinking", "Problem-solving", "Coding", "Continuous learning"]
  },
  {
    id: "pharmacist",
    title: "Pharmacist",
    cluster: "science",
    description: "Dispense medications, provide drug information, and ensure safe medication use.",
    requiredSubjects: ["Mathematics", "Physical Sciences", "Life Sciences"],
    minAPS: 34,
    demandLevel: "high",
    salaryRange: {
      entry: "R450,000 - R550,000",
      mid: "R600,000 - R800,000",
      senior: "R850,000 - R1,500,000"
    },
    studyPaths: ["BPharm (4 years)", "Internship (1 year)"],
    skillsRequired: ["Attention to detail", "Chemistry knowledge", "Communication", "Ethics"]
  },
  // Commerce Cluster
  {
    id: "accountant",
    title: "Chartered Accountant",
    cluster: "commerce",
    description: "Prepare financial statements, conduct audits, provide tax advice, and manage financial records.",
    requiredSubjects: ["Mathematics", "Accounting"],
    recommendedSubjects: ["English", "Economics"],
    minAPS: 32,
    demandLevel: "high",
    salaryRange: {
      entry: "R450,000 - R600,000",
      mid: "R700,000 - R1,200,000",
      senior: "R1,300,000 - R3,000,000"
    },
    studyPaths: ["BCom Accounting (3 years)", "Honours/CTA (1 year)", "SAICA Board Exams", "Training Contract (3 years)"],
    skillsRequired: ["Analytical thinking", "Attention to detail", "Mathematics", "Ethics"]
  },
  {
    id: "lawyer",
    title: "Attorney/Advocate",
    cluster: "commerce",
    description: "Provide legal advice, represent clients in court, draft legal documents, and ensure compliance with laws.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["History", "Mathematics", "Additional languages"],
    minAPS: 30,
    demandLevel: "medium",
    salaryRange: {
      entry: "R350,000 - R500,000",
      mid: "R600,000 - R1,200,000",
      senior: "R1,500,000 - R5,000,000+"
    },
    studyPaths: ["LLB (4 years)", "Articles/Pupillage (2 years)", "Admission exams"],
    skillsRequired: ["Research", "Public speaking", "Writing", "Critical thinking", "Negotiation"]
  },
  {
    id: "marketing-manager",
    title: "Marketing Manager",
    cluster: "commerce",
    description: "Develop marketing strategies, manage campaigns, analyze market trends, and build brand awareness.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["Mathematics/Mathematical Literacy", "Business Studies", "Economics"],
    minAPS: 26,
    demandLevel: "medium",
    salaryRange: {
      entry: "R300,000 - R450,000",
      mid: "R500,000 - R800,000",
      senior: "R900,000 - R1,800,000"
    },
    studyPaths: ["BCom Marketing (3 years)", "BA Communications (3 years)", "Diploma in Marketing"],
    skillsRequired: ["Creativity", "Communication", "Data analysis", "Strategic thinking"]
  },
  {
    id: "hr-manager",
    title: "Human Resources Manager",
    cluster: "commerce",
    description: "Manage recruitment, employee relations, training, compensation, and organizational development.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["Mathematics/Mathematical Literacy", "Business Studies"],
    minAPS: 24,
    demandLevel: "medium",
    salaryRange: {
      entry: "R300,000 - R400,000",
      mid: "R450,000 - R700,000",
      senior: "R750,000 - R1,500,000"
    },
    studyPaths: ["BCom Human Resources (3 years)", "BA Industrial Psychology (3 years)"],
    skillsRequired: ["Communication", "Conflict resolution", "Organization", "Empathy"]
  },
  // Arts Cluster
  {
    id: "teacher",
    title: "Teacher",
    cluster: "arts",
    description: "Educate students at various levels, develop curricula, and assess student progress.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["Teaching subjects of choice", "Mathematics/Mathematical Literacy"],
    minAPS: 24,
    demandLevel: "high",
    salaryRange: {
      entry: "R250,000 - R320,000",
      mid: "R350,000 - R500,000",
      senior: "R550,000 - R800,000"
    },
    studyPaths: ["BEd (4 years)", "PGCE after degree (1 year)"],
    skillsRequired: ["Communication", "Patience", "Organization", "Subject knowledge", "Creativity"]
  },
  {
    id: "journalist",
    title: "Journalist",
    cluster: "arts",
    description: "Research, investigate, and report news stories across print, broadcast, and digital media.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["Additional languages", "History", "Life Sciences"],
    minAPS: 26,
    demandLevel: "medium",
    salaryRange: {
      entry: "R180,000 - R280,000",
      mid: "R300,000 - R500,000",
      senior: "R550,000 - R1,000,000"
    },
    studyPaths: ["BA Journalism (3 years)", "BTech Journalism (4 years)"],
    skillsRequired: ["Writing", "Research", "Curiosity", "Interviewing", "Digital literacy"]
  },
  {
    id: "social-worker",
    title: "Social Worker",
    cluster: "arts",
    description: "Support individuals, families, and communities dealing with challenges like poverty, abuse, and mental health.",
    requiredSubjects: ["English"],
    recommendedSubjects: ["Life Sciences", "Mathematics/Mathematical Literacy"],
    minAPS: 26,
    demandLevel: "high",
    salaryRange: {
      entry: "R220,000 - R300,000",
      mid: "R320,000 - R450,000",
      senior: "R480,000 - R700,000"
    },
    studyPaths: ["BSW Social Work (4 years)"],
    skillsRequired: ["Empathy", "Communication", "Problem-solving", "Resilience", "Cultural sensitivity"]
  },
  {
    id: "graphic-designer",
    title: "Graphic Designer",
    cluster: "arts",
    description: "Create visual content for brands, advertisements, websites, and publications.",
    requiredSubjects: ["Visual Arts/Design"],
    recommendedSubjects: ["English", "IT", "Business Studies"],
    minAPS: 22,
    demandLevel: "medium",
    salaryRange: {
      entry: "R180,000 - R280,000",
      mid: "R300,000 - R500,000",
      senior: "R550,000 - R900,000"
    },
    studyPaths: ["BA Graphic Design (3 years)", "Diploma in Design (3 years)"],
    skillsRequired: ["Creativity", "Software skills", "Typography", "Visual communication"]
  },
  // Technical Cluster
  {
    id: "electrician",
    title: "Electrician",
    cluster: "technical",
    description: "Install, maintain, and repair electrical systems in homes, businesses, and industrial settings.",
    requiredSubjects: ["Mathematics", "Physical Sciences"],
    recommendedSubjects: ["Technical subjects"],
    minAPS: 18,
    demandLevel: "high",
    salaryRange: {
      entry: "R150,000 - R220,000",
      mid: "R250,000 - R400,000",
      senior: "R450,000 - R700,000"
    },
    studyPaths: ["N1-N6 Electrical Engineering", "Trade Test", "Apprenticeship"],
    skillsRequired: ["Technical aptitude", "Problem-solving", "Safety awareness", "Physical fitness"]
  },
  {
    id: "plumber",
    title: "Plumber",
    cluster: "technical",
    description: "Install and repair pipes, fixtures, and other plumbing systems for water and drainage.",
    requiredSubjects: ["Mathematics/Mathematical Literacy"],
    recommendedSubjects: ["Physical Sciences", "Technical subjects"],
    minAPS: 16,
    demandLevel: "high",
    salaryRange: {
      entry: "R140,000 - R200,000",
      mid: "R220,000 - R350,000",
      senior: "R400,000 - R600,000"
    },
    studyPaths: ["N1-N3 Plumbing", "Trade Test", "Apprenticeship"],
    skillsRequired: ["Physical fitness", "Problem-solving", "Customer service", "Technical skills"]
  },
  {
    id: "mechanic",
    title: "Motor Mechanic",
    cluster: "technical",
    description: "Diagnose, repair, and maintain vehicles and their mechanical systems.",
    requiredSubjects: ["Mathematics/Mathematical Literacy"],
    recommendedSubjects: ["Physical Sciences", "Technical subjects"],
    minAPS: 18,
    demandLevel: "high",
    salaryRange: {
      entry: "R140,000 - R200,000",
      mid: "R220,000 - R380,000",
      senior: "R400,000 - R650,000"
    },
    studyPaths: ["N1-N6 Motor Mechanics", "Trade Test", "Apprenticeship"],
    skillsRequired: ["Mechanical aptitude", "Diagnostic skills", "Physical fitness", "Attention to detail"]
  },
  {
    id: "welder",
    title: "Welder",
    cluster: "technical",
    description: "Join metal parts using welding equipment for construction, manufacturing, and repair work.",
    requiredSubjects: ["Mathematics/Mathematical Literacy"],
    recommendedSubjects: ["Physical Sciences", "Technical subjects"],
    minAPS: 16,
    demandLevel: "high",
    salaryRange: {
      entry: "R120,000 - R180,000",
      mid: "R200,000 - R350,000",
      senior: "R380,000 - R600,000"
    },
    studyPaths: ["N1-N3 Welding", "Trade Test", "Apprenticeship", "Short courses"],
    skillsRequired: ["Hand-eye coordination", "Physical fitness", "Safety awareness", "Precision"]
  }
];

export const careerClusters = [
  { id: "science", name: "Science & Technology", description: "Careers in healthcare, engineering, IT, and natural sciences" },
  { id: "commerce", name: "Commerce & Business", description: "Careers in finance, law, marketing, and management" },
  { id: "arts", name: "Arts & Humanities", description: "Careers in education, media, social services, and creative fields" },
  { id: "technical", name: "Technical & Trades", description: "Skilled trades and technical careers" }
];

export function getCareersByCluster(cluster: string): Career[] {
  return careers.filter(c => c.cluster === cluster);
}

export function getCareerRecommendations(subjects: { name: string; mark: number }[]): Career[] {
  const subjectNames = subjects.map(s => s.name.toLowerCase());
  
  return careers.filter(career => {
    const requiredMatch = career.requiredSubjects.some(req => 
      subjectNames.some(sub => sub.includes(req.toLowerCase()) || req.toLowerCase().includes(sub))
    );
    return requiredMatch;
  }).sort((a, b) => {
    // Sort by demand level and APS match
    const demandOrder = { high: 3, medium: 2, low: 1 };
    return demandOrder[b.demandLevel] - demandOrder[a.demandLevel];
  });
}
