// Site-wide configuration and data
// Edit these values to update content across the site

export const siteConfig = {
  name: "Sithetho Foundation",
  alternateName: "New Dawn Foundation",
  tagline: "Phuhlisa • Empower",
  founded: 2024,
  domain: "newdawn.mbilasegroup.com",
  
  founder: {
    name: "Mr. Thandi Sithetho",
    title: "Educator, Founder & Executive Director",
    bio: "A passionate educator from Mdantsane, East London, Mr. Thandi Sithetho founded Sithetho Foundation with a vision to bridge the education gap for underprivileged learners. With years of experience in education and community development, he leads the foundation's mission to empower youth through free guidance and sustainable community initiatives."
  },
  
  contact: {
    whatsapp: "+27 79 129 6823",
    whatsappLink: "https://wa.me/27791296823",
    email: "thando.sithetho@mbilasegroup.com",
    location: "Mdantsane, East London, South Africa"
  },
  
  mission: "Empower learners and communities through free education guidance and sustainable recycling solutions.",
  
  vision: "A South Africa where every learner has equal access to education opportunities and every community is clean, sustainable, and thriving.",
  
  values: [
    {
      name: "Empowerment",
      description: "We believe in equipping individuals with knowledge and tools to shape their own futures."
    },
    {
      name: "Access",
      description: "Education should be accessible to all, regardless of background or circumstance."
    },
    {
      name: "Integrity",
      description: "We operate with transparency, honesty, and accountability in all we do."
    },
    {
      name: "Excellence",
      description: "We strive for the highest standards in everything we deliver."
    },
    {
      name: "Community",
      description: "We are committed to building and strengthening the communities we serve."
    },
    {
      name: "Sustainability",
      description: "We create lasting impact through environmentally and socially responsible practices."
    }
  ],
  
  socialLinks: {
    facebook: "",
    instagram: "",
    twitter: "",
    linkedin: ""
  }
};

export const impactStats = {
  learnersAssisted: 500,
  schoolsPartnered: 15,
  businessesPartnered: 8,
  wasteRecycledKg: 2500,
  communitiesReached: 12,
  volunteerHours: 1200
};

export const recyclingStats = {
  totalWasteKg: 2500,
  paperKg: 1200,
  plasticKg: 800,
  cansKg: 500,
  schoolsRegistered: 15,
  businessesRegistered: 8,
  monthlyCollections: 24
};

export const clcServices = [
  {
    id: "universities",
    title: "Universities",
    description: "Guidance for applying to public and private universities across South Africa.",
    href: "/clc/universities",
    icon: "GraduationCap"
  },
  {
    id: "tvet-colleges",
    title: "TVET & Private Colleges",
    description: "Information and application support for technical and vocational colleges.",
    href: "/clc/tvet-colleges",
    icon: "School"
  },
  {
    id: "aps-calculator",
    title: "APS Calculator",
    description: "Calculate your Admission Point Score and understand what you qualify for.",
    href: "/clc/aps-calculator",
    icon: "Calculator"
  },
  {
    id: "career-guidance",
    title: "Career Guidance",
    description: "Discover career paths that match your subjects, interests, and strengths.",
    href: "/clc/career-guidance",
    icon: "Compass"
  },
  {
    id: "nsfas",
    title: "NSFAS Support",
    description: "Step-by-step assistance with NSFAS applications, documents, and appeals.",
    href: "/clc/nsfas",
    icon: "Wallet"
  },
  {
    id: "book-assistance",
    title: "Book Free Assistance",
    description: "Schedule a free one-on-one session with our education advisors.",
    href: "/clc/book-assistance",
    icon: "Calendar"
  }
];

export const assistanceHours = {
  weekdays: "12:00 – 16:00",
  saturday: "All day",
  sunday: "16:00 – 18:00"
};

export const googleForms = {
  bookAssistance: "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true",
  recyclingRegister: "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true",
  pickupRequest: "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true",
  sponsorPartnership: "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true",
  contactForm: "https://docs.google.com/forms/d/e/YOUR_FORM_ID/viewform?embedded=true"
};

export const faqs = {
  clc: [
    {
      question: "Are all Community Learning Center services really free?",
      answer: "Yes, absolutely! All our services including application guidance, APS calculation, career counseling, and NSFAS support are completely free. We believe every learner deserves access to education guidance regardless of their financial situation."
    },
    {
      question: "Who can use the Community Learning Center services?",
      answer: "Our services are open to all Grade 11 and 12 learners, recent matriculants, and anyone looking to further their education. We primarily serve the Mdantsane and East London communities but welcome learners from across the Eastern Cape."
    },
    {
      question: "How do I book a one-on-one session?",
      answer: "You can book a session through our website by visiting the 'Book Free Assistance' page or by sending us a WhatsApp message. Sessions are available Monday to Friday (12:00-16:00), Saturday (all day), and Sunday (16:00-18:00)."
    },
    {
      question: "Can you help with applications to any university?",
      answer: "Yes, we provide guidance for applications to all public universities, TVET colleges, and many private institutions across South Africa. Our advisors are trained to help with various application processes."
    },
    {
      question: "Do you help with bursary applications?",
      answer: "While our primary focus is on NSFAS applications, we also provide general guidance on other bursary opportunities and can point you to relevant resources for private bursaries."
    }
  ],
  nsfas: [
    {
      question: "What is NSFAS?",
      answer: "The National Student Financial Aid Scheme (NSFAS) is a government bursary scheme that provides financial assistance to eligible South African students who wish to study at public universities and TVET colleges."
    },
    {
      question: "Who qualifies for NSFAS?",
      answer: "South African citizens with a combined household income of R350,000 or less per year, who are admitted to study at a public university or TVET college, and who have not previously been funded for the same qualification level."
    },
    {
      question: "What documents do I need for NSFAS?",
      answer: "You'll need: South African ID, proof of income (parents'/guardians' payslips, affidavits if unemployed, SASSA proof), proof of registration/admission, and consent forms. We can help you prepare all these documents."
    },
    {
      question: "When should I apply for NSFAS?",
      answer: "NSFAS applications typically open in September/October for the following academic year. We recommend applying as early as possible and not waiting until the deadline."
    },
    {
      question: "What if my NSFAS application is rejected?",
      answer: "You can appeal the decision within the specified timeframe. Common reasons for rejection include missing documents, incorrect information, or income verification issues. Our team can help you understand the reason and submit a proper appeal."
    }
  ],
  recycling: [
    {
      question: "What materials does the Recycling Division accept?",
      answer: "We currently accept paper (newspapers, magazines, office paper, cardboard), plastics (bottles, containers marked with recycling symbols), and cans (aluminum and steel). We're working to expand to other materials in the future."
    },
    {
      question: "How does the monthly collection work?",
      answer: "Once registered, we schedule monthly collections from your school or business. We provide collection bins and pick up sorted recyclables. You'll receive a certificate showing your environmental impact."
    },
    {
      question: "Is there a cost for the recycling service?",
      answer: "No, our recycling collection service is free for schools and businesses in our service area. We believe in making recycling accessible to encourage environmental responsibility."
    },
    {
      question: "How does the rewards program work?",
      answer: "Schools and businesses earn points based on the weight and type of materials recycled. Points can be redeemed for certificates, recognition, and special awards. Top recyclers are featured in our impact reports."
    },
    {
      question: "Can individuals participate in the recycling program?",
      answer: "Currently, our collection service is designed for schools and businesses. However, individuals can drop off recyclables at designated collection points. Contact us for the nearest drop-off location."
    }
  ]
};

export const sponsorshipTiers = [
  {
    name: "Community Friend",
    amount: "R500 - R2,000",
    type: "once-off",
    benefits: [
      "Recognition on our website",
      "Thank you certificate",
      "Quarterly newsletter"
    ]
  },
  {
    name: "Education Champion",
    amount: "R2,000 - R10,000",
    type: "once-off",
    benefits: [
      "All Community Friend benefits",
      "Social media recognition",
      "Annual impact report",
      "Invitation to community events"
    ]
  },
  {
    name: "Foundation Partner",
    amount: "R10,000+",
    type: "once-off",
    benefits: [
      "All Education Champion benefits",
      "Logo placement on materials",
      "Direct impact updates",
      "Named sponsorship opportunities"
    ]
  },
  {
    name: "Monthly Supporter",
    amount: "R200+/month",
    type: "monthly",
    benefits: [
      "Ongoing recognition",
      "Monthly impact updates",
      "Priority event invitations",
      "Annual appreciation gift"
    ]
  }
];
