// APS (Admission Point Score) calculation data and logic

export interface APSLevel {
  level: number;
  percentage: string;
  points: number;
}

export const apsLevels: APSLevel[] = [
  { level: 7, percentage: "80-100%", points: 7 },
  { level: 6, percentage: "70-79%", points: 6 },
  { level: 5, percentage: "60-69%", points: 5 },
  { level: 4, percentage: "50-59%", points: 4 },
  { level: 3, percentage: "40-49%", points: 3 },
  { level: 2, percentage: "30-39%", points: 2 },
  { level: 1, percentage: "0-29%", points: 1 }
];

export interface Subject {
  name: string;
  mark: number;
  isLifeOrientation: boolean;
}

export const subjectList = [
  "English Home Language",
  "English First Additional Language",
  "Afrikaans Home Language",
  "Afrikaans First Additional Language",
  "isiXhosa Home Language",
  "isiXhosa First Additional Language",
  "isiZulu Home Language",
  "isiZulu First Additional Language",
  "Mathematics",
  "Mathematical Literacy",
  "Physical Sciences",
  "Life Sciences",
  "Geography",
  "History",
  "Accounting",
  "Business Studies",
  "Economics",
  "Consumer Studies",
  "Tourism",
  "Information Technology",
  "Computer Applications Technology",
  "Engineering Graphics and Design",
  "Agricultural Sciences",
  "Visual Arts",
  "Dramatic Arts",
  "Music",
  "Life Orientation"
];

export function getPointsFromMark(mark: number): number {
  if (mark >= 80) return 7;
  if (mark >= 70) return 6;
  if (mark >= 60) return 5;
  if (mark >= 50) return 4;
  if (mark >= 40) return 3;
  if (mark >= 30) return 2;
  return 1;
}

export function calculateAPS(subjects: Subject[]): {
  totalAPS: number;
  subjectsUsed: { name: string; mark: number; points: number }[];
  explanation: string;
} {
  // Filter out Life Orientation
  const eligibleSubjects = subjects.filter(s => !s.isLifeOrientation && s.mark > 0);
  
  // Calculate points for each subject
  const subjectsWithPoints = eligibleSubjects.map(s => ({
    name: s.name,
    mark: s.mark,
    points: getPointsFromMark(s.mark)
  }));
  
  // Sort by points (highest first)
  subjectsWithPoints.sort((a, b) => b.points - a.points);
  
  // Take best 6 subjects
  const best6 = subjectsWithPoints.slice(0, 6);
  
  // Calculate total APS
  const totalAPS = best6.reduce((sum, s) => sum + s.points, 0);
  
  // Generate explanation
  let explanation = `Your APS is calculated using your best 6 subjects (excluding Life Orientation). `;
  if (subjectsWithPoints.length < 6) {
    explanation += `Note: You only entered ${subjectsWithPoints.length} subjects. For the most accurate APS, enter all your subjects. `;
  }
  explanation += `Maximum possible APS is 42 (7 points × 6 subjects).`;
  
  return {
    totalAPS,
    subjectsUsed: best6,
    explanation
  };
}

export const apsRequirementExamples = [
  {
    programme: "Medicine (MBChB)",
    university: "Most Universities",
    minAPS: "38-42",
    notes: "Highly competitive. Requires Maths, Physical Sciences, Life Sciences."
  },
  {
    programme: "Engineering (BSc/BEng)",
    university: "Most Universities",
    minAPS: "32-38",
    notes: "Requires Maths (Level 5+) and Physical Sciences (Level 5+)."
  },
  {
    programme: "BCom Accounting",
    university: "Most Universities",
    minAPS: "30-36",
    notes: "Requires Maths (not Maths Literacy) and English."
  },
  {
    programme: "LLB Law",
    university: "Most Universities",
    minAPS: "30-35",
    notes: "Strong English required. Some accept Maths Literacy."
  },
  {
    programme: "BA Degree",
    university: "Most Universities",
    minAPS: "26-32",
    notes: "Requirements vary by specialization."
  },
  {
    programme: "BSc General",
    university: "Most Universities",
    minAPS: "28-34",
    notes: "Maths and relevant science subjects required."
  },
  {
    programme: "Diploma Programmes",
    university: "Universities of Technology",
    minAPS: "22-28",
    notes: "Specific subject requirements vary by programme."
  },
  {
    programme: "TVET N Courses",
    university: "TVET Colleges",
    minAPS: "N/A",
    notes: "Grade 9 or Matric required depending on level."
  }
];
