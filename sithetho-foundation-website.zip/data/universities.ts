export interface University {
  id: string;
  slug: string;
  name: string;
  shortName: string;
  type: "public" | "private";
  province: string;
  city: string;
  description: string;
  website: string;
  applicationFee: string;
  applicationDeadline: string;
  lateApplicationDeadline?: string;
  minAPS: number;
  requiredDocuments: string[];
  popularCourses: string[];
  accommodationLink?: string;
  nsfasAccredited: boolean;
  contactEmail?: string;
  contactPhone?: string;
  logo?: string;
}

export const universities: University[] = [
  {
    id: "uct",
    slug: "university-of-cape-town",
    name: "University of Cape Town",
    shortName: "UCT",
    type: "public",
    province: "Western Cape",
    city: "Cape Town",
    description: "The University of Cape Town is the oldest university in South Africa and is consistently ranked as the top university in Africa. UCT is renowned for its research output and academic excellence.",
    website: "https://www.uct.ac.za",
    applicationFee: "R100",
    applicationDeadline: "31 July",
    lateApplicationDeadline: "30 September",
    minAPS: 30,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 mid-year results (if available)",
      "Proof of payment",
      "Matriculation certificate (after results)"
    ],
    popularCourses: ["Medicine", "Law", "Engineering", "Commerce", "Science"],
    accommodationLink: "https://www.uct.ac.za/students/accommodation",
    nsfasAccredited: true,
    contactEmail: "admissions@uct.ac.za",
    contactPhone: "021 650 2128"
  },
  {
    id: "wits",
    slug: "university-of-the-witwatersrand",
    name: "University of the Witwatersrand",
    shortName: "Wits",
    type: "public",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Wits University is a leading African research university situated in the economic heartland of South Africa. It offers a wide range of undergraduate and postgraduate programmes.",
    website: "https://www.wits.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 September",
    minAPS: 28,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Medicine", "Engineering", "Law", "Accounting", "Architecture"],
    accommodationLink: "https://www.wits.ac.za/accommodation",
    nsfasAccredited: true,
    contactEmail: "studentenquiries@wits.ac.za",
    contactPhone: "011 717 1000"
  },
  {
    id: "stellenbosch",
    slug: "stellenbosch-university",
    name: "Stellenbosch University",
    shortName: "SU",
    type: "public",
    province: "Western Cape",
    city: "Stellenbosch",
    description: "Stellenbosch University is one of the oldest universities in South Africa, known for its beautiful campus and strong academic programmes in engineering, science, and business.",
    website: "https://www.sun.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 June",
    lateApplicationDeadline: "31 August",
    minAPS: 30,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 June results",
      "Proof of payment"
    ],
    popularCourses: ["Engineering", "Medicine", "Law", "Agriculture", "Commerce"],
    accommodationLink: "https://www.sun.ac.za/english/learning-teaching/student-affairs/accommodation",
    nsfasAccredited: true,
    contactEmail: "info@sun.ac.za",
    contactPhone: "021 808 9111"
  },
  {
    id: "up",
    slug: "university-of-pretoria",
    name: "University of Pretoria",
    shortName: "UP",
    type: "public",
    province: "Gauteng",
    city: "Pretoria",
    description: "The University of Pretoria is one of the largest residential universities in South Africa, offering a wide variety of programmes across nine faculties.",
    website: "https://www.up.ac.za",
    applicationFee: "R300",
    applicationDeadline: "30 June",
    lateApplicationDeadline: "30 September",
    minAPS: 28,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Veterinary Science", "Medicine", "Engineering", "Law", "Education"],
    accommodationLink: "https://www.up.ac.za/accommodation",
    nsfasAccredited: true,
    contactEmail: "csc@up.ac.za",
    contactPhone: "012 420 3111"
  },
  {
    id: "ukzn",
    slug: "university-of-kwazulu-natal",
    name: "University of KwaZulu-Natal",
    shortName: "UKZN",
    type: "public",
    province: "KwaZulu-Natal",
    city: "Durban",
    description: "UKZN is a multi-campus university with a proud tradition of academic excellence and innovation. It serves students across five campuses in KwaZulu-Natal.",
    website: "https://www.ukzn.ac.za",
    applicationFee: "R240",
    applicationDeadline: "30 September",
    minAPS: 26,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Medicine", "Engineering", "Law", "Agriculture", "Education"],
    accommodationLink: "https://studentresidences.ukzn.ac.za",
    nsfasAccredited: true,
    contactEmail: "applications@ukzn.ac.za",
    contactPhone: "031 260 1111"
  },
  {
    id: "uj",
    slug: "university-of-johannesburg",
    name: "University of Johannesburg",
    shortName: "UJ",
    type: "public",
    province: "Gauteng",
    city: "Johannesburg",
    description: "UJ is a vibrant, multicultural university in the heart of Johannesburg. It is one of the largest contact universities in South Africa with over 50,000 students.",
    website: "https://www.uj.ac.za",
    applicationFee: "R200",
    applicationDeadline: "30 September",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Engineering", "Accounting", "Law", "Science", "Education"],
    accommodationLink: "https://www.uj.ac.za/residence/",
    nsfasAccredited: true,
    contactEmail: "studentenquiries@uj.ac.za",
    contactPhone: "011 559 4555"
  },
  {
    id: "nwu",
    slug: "north-west-university",
    name: "North-West University",
    shortName: "NWU",
    type: "public",
    province: "North West",
    city: "Potchefstroom",
    description: "NWU is a multi-campus university with campuses in Potchefstroom, Mahikeng, and Vanderbijlpark. It is known for strong programmes in education and pharmacy.",
    website: "https://www.nwu.ac.za",
    applicationFee: "R165",
    applicationDeadline: "30 September",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Pharmacy", "Education", "Law", "Engineering", "Theology"],
    accommodationLink: "https://studies.nwu.ac.za/residence",
    nsfasAccredited: true,
    contactEmail: "studies@nwu.ac.za",
    contactPhone: "018 299 4000"
  },
  {
    id: "ufs",
    slug: "university-of-the-free-state",
    name: "University of the Free State",
    shortName: "UFS",
    type: "public",
    province: "Free State",
    city: "Bloemfontein",
    description: "UFS is one of the oldest and most prestigious universities in South Africa, known for its excellent academic programmes and beautiful campus.",
    website: "https://www.ufs.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 September",
    minAPS: 26,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Medicine", "Agriculture", "Law", "Education", "Engineering"],
    accommodationLink: "https://www.ufs.ac.za/housing",
    nsfasAccredited: true,
    contactEmail: "info@ufs.ac.za",
    contactPhone: "051 401 9111"
  },
  {
    id: "rhodes",
    slug: "rhodes-university",
    name: "Rhodes University",
    shortName: "RU",
    type: "public",
    province: "Eastern Cape",
    city: "Makhanda (Grahamstown)",
    description: "Rhodes University is known for its exceptional student-to-staff ratio and consistently high pass and graduation rates. It offers a true residential university experience.",
    website: "https://www.ru.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 September",
    minAPS: 28,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Journalism", "Pharmacy", "Law", "Science", "Commerce"],
    accommodationLink: "https://www.ru.ac.za/residences/",
    nsfasAccredited: true,
    contactEmail: "registrar@ru.ac.za",
    contactPhone: "046 603 8111"
  },
  {
    id: "nmmu",
    slug: "nelson-mandela-university",
    name: "Nelson Mandela University",
    shortName: "NMU",
    type: "public",
    province: "Eastern Cape",
    city: "Port Elizabeth (Gqeberha)",
    description: "Nelson Mandela University is a comprehensive university offering a wide range of programmes from certificates to doctoral degrees across multiple campuses.",
    website: "https://www.mandela.ac.za",
    applicationFee: "R150",
    applicationDeadline: "30 September",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Engineering", "Architecture", "Law", "Education", "Business"],
    accommodationLink: "https://www.mandela.ac.za/Student-Accommodation",
    nsfasAccredited: true,
    contactEmail: "info@mandela.ac.za",
    contactPhone: "041 504 1111"
  },
  {
    id: "wsu",
    slug: "walter-sisulu-university",
    name: "Walter Sisulu University",
    shortName: "WSU",
    type: "public",
    province: "Eastern Cape",
    city: "Mthatha",
    description: "Walter Sisulu University is a comprehensive university serving the Eastern Cape region with campuses in Mthatha, East London, Butterworth, and Komani.",
    website: "https://www.wsu.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 September",
    minAPS: 22,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Health Sciences", "Education", "Agriculture", "Engineering", "Commerce"],
    accommodationLink: "https://www.wsu.ac.za/index.php/student-housing",
    nsfasAccredited: true,
    contactEmail: "info@wsu.ac.za",
    contactPhone: "047 502 2111"
  },
  {
    id: "uforthere",
    slug: "university-of-fort-hare",
    name: "University of Fort Hare",
    shortName: "UFH",
    type: "public",
    province: "Eastern Cape",
    city: "Alice",
    description: "The University of Fort Hare has a rich history and has produced many of Africa's leaders. It continues to provide quality education to students across its campuses.",
    website: "https://www.ufh.ac.za",
    applicationFee: "R100",
    applicationDeadline: "30 September",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Agriculture", "Law", "Education", "Social Sciences", "Science"],
    accommodationLink: "https://www.ufh.ac.za/student-housing",
    nsfasAccredited: true,
    contactEmail: "info@ufh.ac.za",
    contactPhone: "040 602 2011"
  },
  // Private Universities
  {
    id: "monash-sa",
    slug: "monash-south-africa",
    name: "Monash South Africa",
    shortName: "Monash SA",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "Monash South Africa is a campus of Australia's Monash University, offering internationally recognized qualifications with a focus on business, IT, and health sciences.",
    website: "https://www.monash.ac.za",
    applicationFee: "R250",
    applicationDeadline: "Rolling admissions",
    minAPS: 30,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Grade 12 results when available",
      "Proof of payment"
    ],
    popularCourses: ["Business", "Information Technology", "Health Sciences"],
    nsfasAccredited: false,
    contactEmail: "enquiries@monash.ac.za",
    contactPhone: "011 950 4000"
  },
  {
    id: "regent",
    slug: "regent-business-school",
    name: "Regent Business School",
    shortName: "Regent",
    type: "private",
    province: "KwaZulu-Natal",
    city: "Durban",
    description: "Regent Business School is a leading private higher education institution specializing in business and management programmes.",
    website: "https://www.regent.ac.za",
    applicationFee: "R500",
    applicationDeadline: "Rolling admissions",
    minAPS: 22,
    requiredDocuments: [
      "Certified copy of ID",
      "Matric certificate or equivalent",
      "Proof of payment"
    ],
    popularCourses: ["Business Administration", "Management", "Marketing", "Human Resources"],
    nsfasAccredited: false,
    contactEmail: "info@regent.ac.za",
    contactPhone: "031 304 4626"
  },
  {
    id: "afda",
    slug: "afda-film-school",
    name: "AFDA - The School of Motion Picture Medium and Live Performance",
    shortName: "AFDA",
    type: "private",
    province: "Gauteng",
    city: "Johannesburg",
    description: "AFDA is a leading film school offering degrees in motion picture, live performance, and creative business. It has campuses in Johannesburg, Cape Town, Durban, and Port Elizabeth.",
    website: "https://www.afda.co.za",
    applicationFee: "R500",
    applicationDeadline: "Rolling admissions",
    minAPS: 24,
    requiredDocuments: [
      "Certified copy of ID",
      "Grade 11 final results",
      "Creative portfolio (where applicable)",
      "Proof of payment"
    ],
    popularCourses: ["Film Production", "Acting", "Sound Design", "Animation"],
    nsfasAccredited: false,
    contactEmail: "info@afda.co.za",
    contactPhone: "011 482 8345"
  }
];

export const provinces = [
  "Eastern Cape",
  "Free State",
  "Gauteng",
  "KwaZulu-Natal",
  "Limpopo",
  "Mpumalanga",
  "North West",
  "Northern Cape",
  "Western Cape"
];

export function getUniversityBySlug(slug: string): University | undefined {
  return universities.find(u => u.slug === slug);
}

export function filterUniversities(
  province?: string,
  type?: "public" | "private",
  search?: string
): University[] {
  return universities.filter(u => {
    const matchProvince = !province || u.province === province;
    const matchType = !type || u.type === type;
    const matchSearch = !search || 
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.shortName.toLowerCase().includes(search.toLowerCase());
    return matchProvince && matchType && matchSearch;
  });
}
